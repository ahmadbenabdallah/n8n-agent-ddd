# Tunisia DTC Domain

This bounded context is the first reference implementation for `n8n-agent-ddd`.

## Runtime flow

`Messenger → WF-00 → WF-01 → WF-02 → WF-03 → WF-04 → WF-09 → WF-10 → domain service → WF-20 → verification → WF-16 → WF-17`

WF-05 and WF-06 provide sales/support decisioning. WF-07 handles order-service
logic. WF-11–WF-15 cover commerce operations. WF-18 manages approved knowledge.
WF-19 reconciles and monitors the runtime.

## Critical boundary

The LLM may propose an action, but it cannot authorize or execute commerce
mutations. Only WF-10 can authorize privileged commerce execution and only
WF-20 can execute privileged WooCommerce mutations.

## State

Business state is durable outside n8n execution history. Important mutations
are idempotent and follow:

`REQUESTED → AUTHORIZED → EXECUTION_STARTED → WOOCOMMERCE_MUTATION → VERIFICATION → COMPLETED`

Unknown external outcomes enter reconciliation instead of blind retry.
