# n8n-agent-ddd

**Domain-driven autonomous agent runtime built around n8n.**

n8n-agent-ddd provides the architecture, contracts, skills, agent harness, validation gates, security boundaries, and deployment model required to build production-grade autonomous business agents with n8n as the execution runtime.

## Core lifecycle

`DISCOVER → DEFINE → DOMAIN → SPECIFY → ARCHITECT → DESIGN → DECOMPOSE → PLAN → IMPLEMENT → TEST → SECURITY → REVIEW → INTEGRATE → DEPLOY → VERIFY → OPERATE → LEARN`

## Runtime invariant

> LLM proposes → n8n validates → WF-10 authorizes → WF-20 executes → WooCommerce verifies → WF-16 renders → WF-17 audits → WF-19 monitors.

## Architecture

- `platform/` — reusable domain-agnostic primitives.
- `domains/` — concrete business domains; Tunisia DTC is the first reference domain.
- `.agents/` — shared agent skills, roles, policies and references.
- `harness/` — agentic software lifecycle, gates, validators and orchestration.
- `runtime/` — n8n, Supabase, Redis and operational runtime assets.
- `contracts/` — machine-readable boundaries.
- `spec/` — machine-validatable specifications.
- `docs/` — maintainer/developer documentation.
- `docs-user/` — user installation, deployment and operations documentation.

## Quick start

Requirements: Node.js 22 LTS, pnpm 10.x, Git, Docker for runtime.

```bash
pnpm install
pnpm doctor
pnpm validate
pnpm test
```

The canonical agent contract is `AGENTS.md`. Claude and Codex adapters are thin layers over the shared contract and skills.

## Status

Repository foundation. The Tunisia DTC WF-00..WF-20 runtime is added after the platform, contract, validation and harness foundations are stable.

## License

Apache-2.0.


## Phase 6
The Tunisia DTC reference domain and WF-00 → WF-20 specifications are under `domains/tunisia-dtc/`.
