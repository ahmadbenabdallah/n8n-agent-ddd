# Security Policy

Do not disclose vulnerabilities in public issues. Use the repository's private security reporting mechanism when enabled.

High-risk changes include identity, authorization, LLM tool use, prompt injection, secrets, customer data, payment, WooCommerce mutations, n8n credentials, migrations and production deployment.

Core boundary: LLM proposal → n8n validation → WF-10 authorization → WF-20 privileged execution → external verification → rendering → audit.

Never commit API keys, tokens, passwords, payment data, WooCommerce secrets, n8n credentials or production environment files.
