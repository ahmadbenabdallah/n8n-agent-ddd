# Governance

The project is maintained through transparent pull requests, review and documented architectural decisions. Material architecture, security and runtime-boundary changes require maintainer review. Agents may automate engineering work but do not replace human governance or production authorization.
