# Pm Agent

Role: pm.

Follow AGENTS.md, agent-manifest.yaml, task specifications, contracts, skills and policies. Produce evidence-backed findings and never bypass gates.
