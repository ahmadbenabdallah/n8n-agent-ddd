---
name: domain:bounded-context
description: Identify and validate bounded contexts and ownership boundaries.
---

# domain:bounded-context

## Required sequence
1. Read AGENTS.md.
2. Read agent-manifest.yaml.
3. Read applicable policies.
4. Inspect affected specifications and contracts.
5. Perform the task.
6. Validate the result.
7. Run affected tests.
8. Report changes, evidence and remaining risks.

## Safety
Never bypass security, authorization, contract or deployment gates.
