# Contributing

```bash
pnpm install
pnpm doctor
pnpm validate
pnpm test
```

Follow DISCOVER → DEFINE → DOMAIN → SPECIFY → ARCHITECT → DESIGN → DECOMPOSE → PLAN → IMPLEMENT → TEST → SECURITY → REVIEW.

PRs should explain the problem, domain impact, affected contracts/workflows, security impact, tests, migration impact and rollback considerations.
