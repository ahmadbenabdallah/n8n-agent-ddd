# Blue/Green Deployment

Blue and green are runtime slots, not separate business-state stores.

Durable state remains shared in PostgreSQL:

- customer identity
- conversations
- carts
- actions
- authorizations
- transactions
- idempotency
- audit
- reconciliation

During a schema transition both runtime slots must remain compatible with the current schema.

After green passes health and smoke checks, traffic is switched explicitly. Blue is drained before retirement.

If an execution may have reached an external commerce provider, do not blindly retry after rollback. Reconcile the external outcome first.
