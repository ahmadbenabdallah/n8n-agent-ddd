# Production Certification

Production certification is an **evidence decision**, not a label applied
because the repository contains production-looking workflows.

## Required sequence

1. Deploy the exact release candidate to staging.
2. Run preflight and workflow/contract validation.
3. Apply and verify Supabase migrations.
4. Run database security tests.
5. Run WooCommerce staging smoke tests.
6. Run Meta webhook verification tests.
7. Validate structured LLM output.
8. Run the complete E2E suite.
9. Run concurrency/idempotency tests.
10. Inject external-write timeout and prove reconciliation.
11. Run red-team cases.
12. Run load testing.
13. Restore a backup into an isolated environment and verify.
14. Perform blue/green rollback.
15. Detect intentional workflow drift.
16. Obtain architecture and security approvals.
17. Run the machine-readable readiness evaluator.

## Certification rule

The evaluator returns `CERTIFIED` only when every required gate has fresh
PASS evidence, there are no open critical/high findings, and both required
approvals are present.

Otherwise it returns `BLOCKED`.

This repository must never generate a fake PASS merely because an external
test was not run.
