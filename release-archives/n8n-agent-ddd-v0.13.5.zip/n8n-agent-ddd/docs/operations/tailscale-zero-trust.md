# Tailscale zero-trust deployment

## Required production topology

```text
Operator laptop
     │
 Tailscale
     │
     ▼
 VPS / runtime host
 ├── Tailscale
 ├── n8n :5678 (private)
 ├── PostgreSQL (private/external)
 └── reverse proxy / webhook ingress
          ▲
          │ public only where a channel requires inbound webhooks
          │
     Meta / channel provider
```

The n8n editor is not a public website. Tailscale provides the operator access path.

Tailscale's current recommended policy model is Grants, with ACLs retained for compatibility. Both use deny-by-default access control. The deployment should grant the operator group only the n8n UI port and required administrative resources.

External egress is separate from operator ingress. An allowlisted external API may be contacted outbound without making the n8n UI reachable from the Internet.

## Local development

For a developer-only machine, localhost access is sufficient. Tailscale becomes useful when another trusted device needs to reach the local runtime.

## Managed providers

A managed provider may have its own ingress model. Do not assume Tailscale can hide provider ingress unless the provider supports the required private networking. Keep the same invariant: operator UI private; public webhook exceptions isolated.

## Security tests

A production gate must verify:
- public n8n editor port is closed
- public PostgreSQL port is closed
- public SSH is closed or explicitly controlled
- Tailscale operator access works
- webhook endpoints work only where declared
- outbound destinations match the allowlist
- arbitrary LLM-provided URLs are rejected
