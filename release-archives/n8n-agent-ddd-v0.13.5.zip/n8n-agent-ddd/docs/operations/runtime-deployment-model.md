# Runtime Deployment Model

## Principle

n8n is the execution runtime and native operator work surface. The platform does not build a replacement workflow editor.

The runtime is provider-neutral: Docker is the packaging boundary, while the deployment target may be a developer laptop, a VPS, Railway, another container provider, or another infrastructure platform that can run the pinned n8n image and provide durable storage/networking.

## Supported modes

### Local all-in-one

PostgreSQL + n8n run locally through Docker Compose.

```bash
cp infrastructure/environments/local/.env.example .env.local
# edit secrets
set -a; source .env.local; set +a
pnpm runtime:up
```

The n8n editor is then exposed locally on the configured port. PostgreSQL and n8n use named persistent Docker volumes.

### n8n only on a VPS/provider

The VPS/provider runs the official n8n Docker image. PostgreSQL can remain external, for example Supabase or another PostgreSQL provider.

```bash
cp infrastructure/environments/remote-n8n/.env.example .env.remote
# configure the provider's secret store/environment variables
```

Use `docker-compose.n8n-only.yml` when the target supports Docker Compose. For Railway, map the same contract to Railway service variables and a persistent volume; Railway documents deployment from the official `n8nio/n8n` image and recommends a volume for `/home/node/.n8n`. citeturn0search0turn0search3

### VPS all-in-one

Run n8n + PostgreSQL on the VPS with persistent storage. This is the most self-contained deployment and avoids making the developer machine part of production.

## Configuration layers

Do not treat every setting as an environment variable.

1. **Infrastructure config** — deployment environment variables and provider configuration.
2. **n8n runtime config** — n8n environment variables, projects, workflows and credentials.
3. **Domain config** — durable PostgreSQL business configuration.
4. **Secrets** — provider secret store, n8n credentials, or an external secrets system.

Production secrets must never be committed to Git.

## Local developer versus production

A developer can run the complete runtime locally. Production can run n8n independently on a VPS/provider. The repository and CI/CD remain the engineering control plane.

```text
Developer laptop
  ├── Git
  ├── harness
  ├── Claude/Codex
  └── optional local Docker runtime

Production
  ├── GitHub/CI/CD
  ├── n8n container
  ├── PostgreSQL (external or same VPS)
  ├── persistent n8n data
  └── provider networking / TLS
```

The production n8n instance is not required to run on the developer laptop.

## Persistence

PostgreSQL is durable domain/application state. n8n also requires persistence for its own database and encryption material; when using the official Docker image, `/home/node/.n8n` must be persisted. Railway's current n8n deployment guide explicitly calls this out. citeturn0search0

Do not make the n8n filesystem the source of truth for domain state.

## Upgrades

Pin the n8n image version. Do not use `latest` for production.

The release process is:

```text
Git release
  ↓
validate manifest
  ↓
backup durable state
  ↓
pull pinned n8n image
  ↓
migrate
  ↓
health check
  ↓
smoke/E2E
  ↓
traffic switch
```

If n8n's native source-control feature is used, keep its direction aligned with the platform release process; n8n documents multi-instance/multi-branch patterns and recommends avoiding push/pull against the same instance because changes can be overwritten. citeturn1search5

## Provider choice

The platform does not hard-code Railway, a particular VPS vendor, or a particular cloud.

Provider selection is an infrastructure concern. The provider must satisfy the runtime contract:

- Docker/container support
- persistent `/home/node/.n8n`
- PostgreSQL connectivity
- TLS/public URL for required webhooks
- secret/environment configuration
- backups appropriate to the environment
- health/restart support

Railway is therefore a valid deployment adapter, not a platform dependency. Railway currently supports deploying the official n8n Docker image, provider variables, persistent volumes, and PostgreSQL services. citeturn0search0turn0search2
