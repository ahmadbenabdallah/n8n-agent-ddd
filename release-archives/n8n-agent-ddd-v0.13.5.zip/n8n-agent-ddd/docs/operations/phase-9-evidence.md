# Phase 9 Evidence Bundle

Store generated evidence outside Git when it contains secrets, customer data,
tokens, or private infrastructure details.

Minimum evidence:

- migration output
- database security test output
- n8n workflow import/validation output
- WooCommerce read/write verification
- Meta webhook signature tests
- structured LLM schema validation
- Messenger E2E transcript with synthetic identities
- idempotency/concurrency results
- timeout/reconciliation results
- red-team results
- load-test report
- backup/restore report
- blue/green rollback report
- workflow drift report
- architecture/security approvals

Evidence should identify:

- release version
- workflow version
- database schema version
- business/security/LLM/KB versions
- environment
- timestamp
- test dataset identifier
- operator/run identifier

Never put production secrets or customer PII into the evidence bundle.
