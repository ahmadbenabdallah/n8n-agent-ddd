# Local Runtime

## v0.12.8

The local runtime uses:

- PostgreSQL 16 with persistent Docker volume.
- n8n `2.39.8` pinned as the current stable release verified on 2026-09-19.
- n8n instance-level MCP at `/mcp-server/http`.
- Official n8n Skills as the agent-facing procedural layer.

The official n8n Skills documentation states that the Skills pair with
instance-level MCP and that n8n 2.2.0 is the minimum; workflow creation/update
via the documented MCP tools requires newer n8n versions, so this project now
pins a current stable 2.39.8 release.

The project does not use a shell script pretending to be an MCP client.
Instead, the Harness/Claude/Codex MCP session performs workflow operations
through the official n8n MCP tools.

The repository can generate a deterministic desired-state sync plan:

```bash
pnpm runtime:sync:plan
```

The plan covers WF-00..WF-20 and requires discovery before mutation.

Live MCP synchronization still requires a running local n8n instance and an
authenticated MCP-capable agent session. It is not claimed as executed here.
