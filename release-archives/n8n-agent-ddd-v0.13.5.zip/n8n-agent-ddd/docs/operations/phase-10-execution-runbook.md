# Phase 10 Execution Runbook

This is the first execution phase. The repository can automate gates, but it
cannot manufacture the external staging infrastructure or credentials needed
to produce valid evidence.

## Preconditions

- A dedicated staging n8n instance is available.
- Staging Postgres/Supabase is available.
- Staging commerce platform is available, if the domain has a commerce adapter.
- Staging channel/webhook credentials are available.
- LLM staging credentials are available.
- All data is synthetic or explicitly approved staging data.
- Production credentials are prohibited.

## Run

```bash
pnpm staging:preflight
pnpm readiness:workflows
pnpm readiness:contracts
pnpm staging:smoke
```

Create an evidence run:

```bash
./scripts/readiness/create-run.sh
```

Execute the evidence suites from the production-certification runbook.

Each suite writes one signed/traceable JSON evidence record containing:

- run_id
- release
- environment
- timestamp
- gate
- PASS/FAIL
- artifacts
- findings
- operator

Then:

```bash
pnpm readiness:evaluate
```

## Gate order

1. INT — integrations
2. SEC — database/runtime security
3. E2E — end-to-end customer journeys
4. IDEMP — concurrency/idempotency
5. RECON — failure/reconciliation
6. RT — red team
7. LOAD — load/performance
8. DR — backup/restore
9. BG — blue/green rollback
10. DRIFT — workflow drift
11. ARCH — architecture approval
12. SECURITY — security approval

## Production rule

Do not deploy production from a partially passing run.

`BLOCKED` is the correct result when evidence is absent, failed, stale, or
unapproved.
