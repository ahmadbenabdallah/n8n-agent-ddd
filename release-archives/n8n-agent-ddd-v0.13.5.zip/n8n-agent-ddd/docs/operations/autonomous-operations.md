# Phase 12 — Autonomous Operations

Phase 12 operates the deployed runtime continuously without allowing operational automation to become business authorization.

## Control loop

```text
Observe → Classify → Decide → Act → Verify → Audit → Learn
```

## Self-healing

Allowed actions are bounded to disposable/runtime problems. Autonomous operations may not authorize commerce, alter price/stock/payment state, export credentials, or retry unknown external commerce outcomes.

## Reconciliation

Unknown external execution is first-class state. The system queries the external source of truth and records the evidence before retrying or compensating.

## Drift

Git remains the workflow source of truth. Unexpected production workflow drift alerts and can block promotion. Production is not silently overwritten.

## Cost/model operations

Record model version, prompt version, token usage, latency and estimated cost. Model/prompt changes are versioned releases, not ad-hoc runtime mutations.

## Human ownership

When a human owns an escalation or incident, conflicting automation must stop until ownership is released.
