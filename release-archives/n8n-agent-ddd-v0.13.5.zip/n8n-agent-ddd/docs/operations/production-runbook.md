# Production Runbook

## Pre-deploy
1. Confirm release manifest.
2. Confirm Phase 10 certification evidence is current.
3. Confirm backups.
4. Confirm migration compatibility.
5. Confirm runtime secrets are available.
6. Confirm rollback target.
7. Confirm monitoring and alerting.

## Green deployment
1. Start green runtime.
2. Apply compatible migrations.
3. Load domain workflows.
4. Bind runtime credentials.
5. Run health checks.
6. Run smoke tests.
7. Obtain explicit promotion approval.

## Traffic switch
1. Stop accepting new traffic on blue.
2. Route new traffic to green.
3. Drain active blue executions.
4. Verify critical workflows.
5. Record release.

## Rollback
1. Freeze conflicting automation if required.
2. Preserve logs/audit/idempotency evidence.
3. Determine whether external execution occurred.
4. Reconcile unknown commerce outcomes.
5. Switch traffic back only after safe target is confirmed.
6. Verify.
7. Record incident and rollback evidence.
