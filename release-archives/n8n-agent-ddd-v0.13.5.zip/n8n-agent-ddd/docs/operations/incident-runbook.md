# Incident Runbook

1. Detect and classify severity.
2. Preserve audit, execution and reconciliation evidence.
3. Freeze conflicting automation when business-state integrity is at risk.
4. Determine whether external mutations occurred.
5. Reconcile unknown outcomes.
6. Restore healthy runtime or roll back candidate release.
7. Verify authorization, commerce and audit paths.
8. Resolve or escalate.
9. Record root cause and corrective action.

Never use an operational incident action as a reason to bypass WF-10.
