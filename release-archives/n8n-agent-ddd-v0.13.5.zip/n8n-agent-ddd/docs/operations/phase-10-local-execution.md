# Phase 10 Local Execution

Phase 10 is split into two execution tracks:

- **Local:** deterministic repository/runtime validation that can run without external credentials.
- **Staging:** real integration evidence against the configured staging environment.

Local execution MUST NOT be interpreted as production certification.

## Local gates

The local runner validates:

- workflow artifacts
- contracts
- architecture invariants
- domain manifests
- agent/skill structure
- release/evidence schemas
- deterministic security checks
- idempotency/reconciliation specification checks
- Phase 10 command-map consistency

## Staging remains

The staging environment and its evidence requirements remain intact. Real integration, E2E, load, disaster-recovery, blue/green, drift, and external security evidence still require an actual staging/runtime environment.

## Commands

```bash
pnpm readiness:local
pnpm readiness:evaluate:local
```

If the repository does not yet expose these package scripts, run:

```bash
bash scripts/readiness/local/run-local.sh
```
