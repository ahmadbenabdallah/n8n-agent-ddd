# Production Database Operations

## Migration

Production database changes use **expand → migrate → contract**.

The application/workflow release must remain compatible with both the previous and new schema during the transition.

Destructive changes are separated into a later contract release. When a destructive database rollback is unsafe, use a forward-compatible fix rather than attempting to reverse already-applied destructive changes.

## Backup

Before production migration:

1. verify a fresh backup exists;
2. verify backup integrity;
3. record schema/runtime release versions;
4. apply migration;
5. verify critical tables, indexes, extensions and RLS;
6. run smoke tests.

## Restore

Restores are performed into a designated verification/recovery database before being considered usable for disaster recovery.

Never test restore directly against production.

## Source of truth

PostgreSQL owns durable application/domain state. n8n execution history is not the source of truth.
