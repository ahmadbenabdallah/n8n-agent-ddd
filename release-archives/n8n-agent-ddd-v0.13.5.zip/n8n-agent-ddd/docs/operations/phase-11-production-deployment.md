# Phase 11 — Production Deployment

Phase 11 turns the repository into a reproducible production deployment path.

## Current status

**Implementation foundation. Production deployment is not certified.**

Phase 10 external staging evidence remains a prerequisite to production promotion.

## Deployment path

```text
Git
 ↓
CI validation
 ↓
Build release
 ↓
Database compatibility check
 ↓
Deploy Green
 ↓
Health check
 ↓
Smoke test
 ↓
Explicit approval
 ↓
Traffic switch
 ↓
Drain Blue
 ↓
Production verification
 ↓
Release evidence
```

## Production boundaries

- PostgreSQL owns durable application/domain state.
- n8n owns orchestration/runtime execution.
- WF-10 is the commerce authorization boundary.
- WF-20 is the privileged commerce adapter boundary.
- LLM output is proposal-only.
- Production secrets are injected at runtime.
- Git is the deployment source of truth.
- Unknown external outcomes require reconciliation.

## Promotion rule

Do not promote production until the required Phase 10 evidence has been executed against the real staging environment and the required architecture/security approvals exist.

## Rollback

Rollback is release-oriented. If a commerce mutation may already have happened, do not blindly retry or compensate. Reconcile the external system first, preserve idempotency evidence, and then decide the safe recovery path.
