# Customer Runtime Configuration & Extensions

Phase 12.8 establishes a safe end-user customization surface after deployment.

## Four ownership classes

| Class | Owner | Durable source | End-user editing |
|---|---|---|---|
| Platform core | Platform | Git release | No |
| Business configuration | Customer | PostgreSQL | Yes |
| Customer extension | Customer | n8n + extension registry | Yes, subject to permissions |
| Secrets | Customer/platform | n8n credentials or external secrets | Yes, raw values never enter agent context |
| Infrastructure | Platform/deployer | deployment environment | No raw `.env` editing |

## Workflow policy

The following workflows remain protected platform core:

- WF-01 Security Gate
- WF-10 Action Authorization
- WF-15 Transaction/Payment
- WF-20 WooCommerce Gateway

Customer extensions must not replace or mutate these invariants. n8n user permissions and project boundaries still apply.

## Configuration

Business settings such as currency, COD enablement, support hours, feature flags, and maximum business discount are stored as versioned PostgreSQL state. Changes use optimistic versioning and produce an audit/change record.

Infrastructure variables such as database URLs, encryption keys, provider API keys, and runtime secrets are not exposed as ordinary customer configuration. Use deployment configuration and n8n credentials/external secrets instead.

## Upgrade behavior

1. Back up durable state.
2. Snapshot configuration and extension registry.
3. Deploy the new platform core to green.
4. Validate protected workflow invariants.
5. Check extension compatibility.
6. Switch traffic only after health/smoke gates pass.
7. Preserve customer configuration and compatible extensions.
8. Disable incompatible extensions explicitly rather than overwriting them.

MCP remains an operator/developer control interface. MCP capability does not equal business authorization; commerce mutations still require WF-10 and execute through WF-20.
