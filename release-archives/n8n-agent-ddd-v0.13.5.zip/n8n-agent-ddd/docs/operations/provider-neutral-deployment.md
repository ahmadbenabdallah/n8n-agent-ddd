# Provider-neutral deployment

The platform does not select a hosting provider.

## Supported profiles

- `local`: PostgreSQL + n8n in Docker.
- `vps`: n8n in Docker on a VPS, PostgreSQL external.
- `vps_all`: n8n + PostgreSQL on a VPS.
- `railway`: n8n container on Railway with managed or external PostgreSQL.

All profiles run the same pinned n8n image and the same domain/runtime contracts.

## Configuration boundary

Infrastructure and secrets are deployment-owned. Business configuration is durable application state in PostgreSQL. Workflow editing uses the native n8n UI and permitted n8n project/workflow surfaces.

Never put production secrets in Git.

## Production rule

A provider adapter is valid only when it supplies persistence, secrets, HTTPS, health checks, backup/restore and rollback evidence.
