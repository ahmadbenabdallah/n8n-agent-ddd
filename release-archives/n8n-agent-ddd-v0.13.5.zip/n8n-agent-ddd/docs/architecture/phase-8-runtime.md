# Phase 8 — Executable n8n Runtime

All WF-00 → WF-20 now have importable n8n workflow artifacts.

Critical boundaries:
- WF-09: proposal only
- WF-10: deny-by-default authorization
- WF-16: verified-facts-only rendering
- WF-17: audit
- WF-19: reconciliation/monitoring
- WF-20: allowlisted WooCommerce execution + idempotency + verification

No provider credentials are committed. Runtime credentials are configured in
n8n.

Production activation remains blocked until Phase 9 staging E2E, failure
injection, load, backup/restore and rollback validation passes.
