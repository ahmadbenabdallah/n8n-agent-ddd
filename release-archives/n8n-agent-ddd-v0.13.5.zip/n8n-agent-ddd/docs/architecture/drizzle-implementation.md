# Drizzle Implementation

Drizzle is the typed TypeScript application ORM for the PostgreSQL data plane.

## Responsibilities

Drizzle owns:

- typed table definitions
- typed application queries
- repository implementations
- normal schema evolution
- migration generation where appropriate

Raw PostgreSQL SQL remains required for:

- RLS
- GRANT/REVOKE
- security policies
- triggers
- functions
- pgvector extensions
- specialized indexes
- PostgreSQL-specific operational controls

## Boundary

```text
Domain/Application
      ↓
Repository Port
      ↓
Drizzle Repository
      ↓
PostgreSQL
      ↑
Raw SQL migrations for PostgreSQL-specific capabilities
```

Supabase remains a supported platform profile, not a domain dependency.

## Production rule

Production migrations must pass the Phase 11 deployment gates. The migration runner refuses production execution unless the explicit deployment gate enables it.
