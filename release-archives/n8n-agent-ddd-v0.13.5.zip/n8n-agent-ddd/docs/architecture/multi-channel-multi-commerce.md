# Multi-Channel / Multi-Commerce Architecture

## The key idea

A customer should not be coupled to the technology used to reach them.

Likewise, the domain should not know whether the merchant runs WooCommerce,
Shopify, PrestaShop, or a custom commerce stack.

The architecture therefore uses **ports and adapters around the DDD core**.

```text
                    ┌─────────────────────┐
WhatsApp ──────────►│                     │
Messenger ─────────►│   Channel Adapters  │
Telegram ──────────►│                     │
Webchat ───────────►└──────────┬──────────┘
                               │ CanonicalMessage
                               ▼
                    ┌─────────────────────┐
                    │ Application Layer   │
                    │ use cases / policies │
                    │ auth / idempotency   │
                    └──────────┬──────────┘
                               │ Commands
                               ▼
                    ┌─────────────────────┐
                    │     DDD Domain      │
                    │ Customer / Cart /   │
                    │ Order / Promotion   │
                    └──────────┬──────────┘
                               │ Ports
                               ▼
                    ┌─────────────────────┐
                    │ Commerce Adapters   │
                    └──┬────┬────┬───────┘
                       │    │    │
                 WooCommerce Shopify PrestaShop
                              │
                         Custom API
```

## What stays unchanged

The domain rules remain stable:

- customer identity
- cart rules
- promotion eligibility
- order scope
- authorization
- payment separation
- idempotency
- reconciliation
- human handoff
- audit

## What changes

Only the adapter mapping changes.

For example:

```yaml
channel_adapter: whatsapp
commerce_adapter: shopify
```

The application still executes a canonical operation such as:

```text
AddItemToCart
```

It does not execute:

```text
POST /wp-json/wc/v3/...
```

or:

```text
POST /admin/api/...
```

Those provider-specific details belong exclusively to the adapter.

## n8n's role

n8n remains the runtime/orchestration engine.

A workflow can therefore look like:

```text
Provider Event
    ↓
Channel Adapter
    ↓
Canonical Message
    ↓
WF-01 Security
    ↓
WF-02 Identity
    ↓
WF-04 Intent
    ↓
Application Command
    ↓
WF-10 Authorization
    ↓
Commerce Adapter
    ↓
Provider
    ↓
Verification
    ↓
Canonical Result
    ↓
WF-16 Renderer
    ↓
Channel Adapter
```

The same application flow can therefore serve:

```text
WhatsApp + Shopify
WhatsApp + WooCommerce
Messenger + WooCommerce
Telegram + PrestaShop
Webchat + Custom API
```

without creating separate business logic implementations.

## DDD versus "just integrations"

DDD is useful here because the business concepts are more stable than vendor
APIs.

The correct abstraction is not:

`WooCommerceService -> ShopifyService`

It is:

`CommercePort -> WooCommerceAdapter`
`CommercePort -> ShopifyAdapter`

The domain speaks in business language; adapters translate provider language.

## When an adapter is not enough

If a platform has genuinely different business semantics, do not distort the
canonical model merely to make the adapter fit.

Instead use one of:

1. a provider capability extension
2. an application policy
3. a separate bounded context
4. an anti-corruption layer
5. a provider-specific integration workflow

The rule is:

> **Normalize stable business semantics; isolate unstable provider mechanics.**
