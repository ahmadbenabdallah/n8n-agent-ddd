# Domain Promotion Flow

```text
Domain Project
      ↓
./harness validate
      ↓
adapter compatibility
      ↓
domain tests
      ↓
security tests
      ↓
n8n workflow validation
      ↓
Git PR
      ↓
DEV n8n Project
      ↓
STAGING n8n Project
      ↓
E2E / red-team / load / DR
      ↓
Certification gate
      ↓
PROD n8n Project
```

A domain project can be promoted independently from another domain while
sharing the same platform runtime, provided the environment and isolation
contracts permit it.
