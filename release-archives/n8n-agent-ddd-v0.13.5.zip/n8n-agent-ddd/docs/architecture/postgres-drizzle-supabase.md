# Postgres, Drizzle, Supabase and pgvector

## Decision

Use **PostgreSQL as the durable database contract**, **Drizzle ORM** for
TypeScript application access and schema typing, and **pgvector** for the
knowledge/RAG vector store.

Use **Supabase as the default managed Postgres platform profile**.

This preserves portability without giving up Supabase's operational features.

Supabase documents that every project is a full Postgres database, and it
supports direct connections and poolers. Supabase also documents first-class
Drizzle integration. Therefore Drizzle can connect directly to the Supabase
Postgres database rather than forcing the application through the Supabase
Data API.

## Recommended layering

```text
Domain
  ↓
Application repositories / ports
  ↓
Drizzle
  ↓
PostgreSQL
  ├── domain state
  ├── audit
  ├── idempotency
  ├── projections
  └── pgvector KB
       ↓
   embeddings / retrieval
```

Supabase then supplies optional platform capabilities around that database:

```text
Supabase
 ├── managed Postgres
 ├── pgvector
 ├── RLS
 ├── Auth (optional)
 ├── Storage (optional)
 ├── Realtime (optional)
 ├── Edge Functions (optional)
 └── operational tooling
```

## Connection strategy

For a persistent n8n/backend runtime, use the appropriate persistent
connection mode. For serverless/short-lived functions, use the appropriate
transaction pooler and disable prepared statements where required.

Do not hard-code a Supabase hostname into the domain or ORM layer.

Use:

```text
DATABASE_URL
DATABASE_PROVIDER=postgres
DATABASE_PROFILE=supabase
```

The deployment chooses the actual connection string.

## Drizzle's role

Drizzle is a good fit for:

- typed schema
- SQL queries
- transactions
- migrations
- Postgres-specific types
- application repository implementation

It does **not** replace Supabase itself.

It also does not remove the need for raw SQL when PostgreSQL-specific
features, RLS policies, functions, triggers, or pgvector indexes require it.

The architecture should therefore permit:

```text
Drizzle ORM
+
versioned SQL migrations
```

rather than forcing every database feature through the ORM abstraction.

## Portability rule

A deployment may switch from:

```text
Supabase Postgres
```

to:

```text
managed PostgreSQL
```

without changing domain logic.

Only the infrastructure profile changes.

## pgvector

The KB remains in Postgres using pgvector.

This is preferable to introducing a separate vector database for the first
production architecture because relational domain state and knowledge
retrieval can share the same durable Postgres infrastructure while remaining
logically separated.

The vector store is still behind `VectorStorePort`, so a future dedicated
vector provider can be introduced without rewriting the domain.
