# Production Adapter Strategy

## User configuration

A deployment selects two independent dimensions:

```yaml
channel:
  provider: meta_messenger

commerce:
  provider: shopify
```

This is valid.

Another deployment can use:

```yaml
channel:
  provider: whatsapp

commerce:
  provider: woocommerce
```

The domain is identical.

## Adapter lifecycle

Every provider adapter should pass:

1. Contract conformance
2. Credential isolation check
3. Capability declaration
4. Read-only integration tests
5. Mutation tests
6. Idempotency tests
7. Timeout/reconciliation tests
8. Security tests
9. E2E channel-to-commerce tests
10. Versioned compatibility declaration

## Capability negotiation

Adapters expose capabilities such as:

```yaml
capabilities:
  catalog_search: true
  inventory: true
  cart: true
  coupon_validation: true
  order_create: true
  order_update: true
  payment_status: true
```

The application must not assume every provider supports every capability.

Unsupported operations return an explicit domain/application capability error.

## Source of truth

For commerce deployments, the selected commerce platform is authoritative
for commerce facts.

The agent does not become a shadow commerce database.

It may cache/projection data for performance, but every sensitive mutation
must be validated against the commerce source of truth before commit and
verified after mutation.

This allows:

```text
Meta Messenger + Shopify
WhatsApp + Shopify
Meta Messenger + WooCommerce
WhatsApp + PrestaShop
Webchat + Custom Commerce
```

without duplicating the DDD core.
