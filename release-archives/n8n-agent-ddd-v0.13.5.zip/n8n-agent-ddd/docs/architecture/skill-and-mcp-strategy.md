# Skills and MCP Strategy

Use existing high-quality skills and MCP integrations as **developer
acceleration**, not as replacements for our domain contracts.

## n8n

Use the official n8n Skills with the n8n MCP server where available.

The n8n project documents skills covering workflow lifecycle, expressions,
sub-workflows, AI agents, error handling, credentials, debugging and related
topics. The skills repository also uses hooks to encourage skill lookup before
high-impact MCP operations.

Our wrapper layer adds:

- DDD invariants
- WF-10 authorization constraints
- WF-20 execution constraints
- naming conventions
- workflow contract validation
- production gates

## Supabase

Use the official Supabase Agent Skills when changing Supabase/Postgres.

The Supabase documentation specifically provides skills for Supabase and a
Postgres-best-practices skill covering schema design, migrations, RLS,
indexes, pgvector, queues and restore operations.

Our wrapper layer adds:

- domain schema boundaries
- security invariants
- migration compatibility rules
- audit/idempotency requirements
- environment rules
- portability requirements

## MCP boundary

MCP is a control interface for agents.

It does not become a business authorization mechanism.

The effective architecture is:

```text
Agent
 ↓
Skill discovery
 ↓
MCP/tool discovery
 ↓
Tool policy
 ↓
Task/architecture gates
 ↓
n8n / Supabase / provider tools
 ↓
runtime contracts
 ↓
WF-10 for commerce mutations
```

OpenClaw's tool policy and plugin architecture are useful references for this
layer: capabilities are filtered before tools become available, and plugins
declare ownership of surfaces. We should adopt those architectural ideas
without coupling the project runtime to OpenClaw.
