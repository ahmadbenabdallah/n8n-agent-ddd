# Phase 9 — Staging Integration & Validation

Phase 9 connects the Phase 8 contract-executable runtime foundation to staging
integrations and turns the architecture into an evidence-driven validation
program.

## Scope

- Supabase migrations and security tests
- self-hosted n8n staging runtime
- WooCommerce staging integration
- Meta Messenger webhook/send integration
- structured LLM output validation
- end-to-end customer scenarios
- concurrency and idempotency tests
- timeout/unknown-outcome reconciliation
- red-team scenarios
- load testing
- backup/restore
- blue/green rollback
- workflow drift detection

## Important distinction

Phase 9 is a **staging validation foundation**, not a production certification.
The repository can define and automate gates, but production certification
requires execution against the operator's actual staging infrastructure,
real integration credentials, evidence retention, review, and successful
failure/recovery tests.

## Runtime proof chain

Inbound:
Meta -> WF-00 -> WF-01 -> WF-02 -> WF-03 -> WF-04

Reasoning:
WF-09 proposes -> WF-10 authorizes -> domain action executes

Commerce:
WF-20 -> WooCommerce -> verification -> WF-16 -> WF-17

Operations:
WF-19 -> reconciliation / drift / health / alerts

## Staging requirements

Required environment variables are documented in
`infrastructure/environments/staging/.env.example`. Secrets must be injected
by the deployment environment or n8n credential store and never committed.

## Exit criteria

See `spec/domains/tunisia-dtc-phase-9.yaml`,
`tests/e2e/phase-9-scenarios.yaml`, and
`tests/integration/phase-9-matrix.yaml`.

Production remains blocked until the evidence bundle is complete.
