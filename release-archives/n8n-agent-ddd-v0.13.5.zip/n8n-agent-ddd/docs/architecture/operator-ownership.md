# Operator Ownership Model

This project is an installable agent runtime. The person or organization deploying a domain is the **operator**. This is intentionally distinct from the end consumer who chats with the agent.

## Ownership

| Surface | Owner | Source of truth | Editable in n8n | Release controlled |
|---|---|---|---|---|
| Platform core | Platform | Git | No | Yes |
| Business configuration | Operator | PostgreSQL | No | No |
| Permitted extensions | Operator | n8n | Yes | No |
| Secrets | Operator / secret provider | n8n credentials or external secrets | Credential surface | No |
| Infrastructure | Deployment system | deployment config | No | Yes |

## No custom UI assumption

The runtime does not require a custom administration dashboard. The supported control surfaces are:

1. deployment configuration for infrastructure;
2. PostgreSQL-backed configuration contracts for business settings;
3. native n8n for permitted workflow/extension editing;
4. n8n credentials or an external secret provider for secrets;
5. Claude/Codex + Skills + MCP + Git/CI for engineering changes.

A future UI can be added as another operator surface without becoming a source of truth.

## Protected workflows

`WF-01`, `WF-10`, `WF-15`, and `WF-20` remain platform-owned. Operator customization cannot replace or bypass them.

## Upgrade invariant

Platform releases may replace platform-owned runtime artifacts. They must preserve operator-owned configuration, compatible extensions, credentials, and durable business state. Incompatible extensions are quarantined rather than silently modified.
