# Domain Projects in n8n

## The model

Every DDD bounded context becomes a **Domain Project Package**.

Example:

```text
n8n-agent-ddd
│
├── domains/
│   ├── tunisia-dtc/
│   ├── travel-umrah/
│   ├── dental-clinic/
│   └── future-domain/
│
└── runtime/n8n/
```

Each domain package owns its domain contract, workflows, policies, adapters,
tests and knowledge profile.

## How it maps into n8n

n8n supports Projects that group workflows and credentials and assign project
roles. This makes a project a useful operational boundary for a bounded
context. n8n documents project-level RBAC and project-specific credentials.

Recommended:

```text
DEV n8n
 ├── domain-tunisia-dtc
 ├── domain-umrah
 └── domain-dental

STAGING n8n
 ├── domain-tunisia-dtc
 ├── domain-umrah
 └── domain-dental

PROD n8n
 ├── domain-tunisia-dtc
 ├── domain-umrah
 └── domain-dental
```

The exact number of n8n instances is an operational decision. A single
instance per environment is efficient for multiple domains; separate n8n
instances provide stronger isolation when required.

## What belongs to a domain project

- domain workflows
- domain-specific credentials
- domain configuration
- domain adapter bindings
- domain tests
- domain knowledge namespace
- domain authorization policy

## What does NOT belong only in n8n

The canonical domain specification stays in Git.

n8n is the execution/deployment target.

```text
Git
 ↓
Domain Package
 ↓
CI validation
 ↓
n8n Project
 ↓
Runtime
```

## Source control

n8n's current source-control model links an n8n instance to a Git branch and
supports pushing/pulling workflows, projects, folders, tags and credential
stubs. Credentials and variable values themselves are not stored in Git.

For our project, Git remains canonical and CI controls promotion. Production
n8n should be protected from direct editing.

## Isolation caveat

n8n projects are useful boundaries, but not our complete security model.

n8n documents that tags and variables are global across the instance, so they
must not be treated as tenant/domain security boundaries.

Our own domain isolation therefore additionally requires:

- domain IDs
- workflow namespaces
- project-scoped credentials
- Postgres schema/domain scoping
- KB/vector namespaces
- explicit cross-domain contracts
- authorization checks
- audit events

## Cross-domain communication

Default:

```text
Domain A ──X──> Domain B
```

If communication is required:

```text
Domain A
   ↓
Published Contract / Domain Event
   ↓
Authorization
   ↓
Domain B Adapter
```

Never directly call another domain's private workflow just because n8n makes
the workflow technically reachable.

## Multiple customers

If this platform becomes SaaS and different customers must be strongly
isolated, prefer separate domain/customer runtime instances or an explicitly
designed tenant isolation model. Do not rely solely on n8n Projects for a
hard security boundary.
