# Capability Control Plane

The runtime separates four concepts:

- **Skill:** procedural knowledge.
- **Tool:** executable capability.
- **Plugin:** packaged capability/adapter.
- **MCP:** agent/developer control interface.

None of these automatically grants authorization.

## Security boundary

```text
Agent
  ↓
Skill Router
  ↓
Tool Policy
  ↓
MCP / Tool / Plugin
  ↓
Platform Port
  ↓
WF-10
  ↓
WF-20
  ↓
Commerce
```

MCP can manage workflows and inspect systems, but it cannot bypass the commerce authorization boundary.

## Upstream skills

Official n8n and Supabase skill ecosystems are registered as upstream providers. The repository's own DDD/security skills remain canonical.

External material must pass license, provenance, version/commit and attribution checks before vendoring.
