# Runtime & Release Control Plane

The project has four planes:

1. Agent control: Harness, Skills, MCP, agents, policies.
2. Release control: CI/CD, validation, provenance, signing, deployment.
3. Runtime execution: n8n and WF-00..WF-20.
4. Durable data: PostgreSQL, domain state, audit, knowledge.

n8n Skills/MCP are the agent-facing interface for supported n8n discovery and controlled operations. They do not replace deterministic CI/CD and do not authorize commerce.

Production accepts only releases with verified provenance/signature and required staging evidence.

n8n containers are disposable. PostgreSQL/domain state are durable. Migrations use expand/migrate/contract where required.
