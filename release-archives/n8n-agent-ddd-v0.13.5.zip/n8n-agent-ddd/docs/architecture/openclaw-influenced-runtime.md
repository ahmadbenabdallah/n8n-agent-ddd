# OpenClaw-Inspired Execution Model

OpenClaw is useful as an architectural reference, not as the runtime replacement
for this project.

## Patterns worth borrowing

### 1. Gateway/control-plane separation

OpenClaw has a long-lived Gateway that owns channel connections, sessions,
routing and control-plane access.

For n8n Agent DDD, the equivalent is:

- n8n runtime/orchestration
- durable domain state
- channel adapters
- adapter registry
- policy/authorization layer

The key lesson is one authoritative owner for each responsibility.

### 2. Skills are procedural knowledge

OpenClaw treats tools as actions and skills as instructions explaining how to
use those actions. Its skill system supports precedence, gating and
environment-based eligibility.

We should keep `.agents/skills` as the canonical project skill layer and add
provider skills around it:

- `channel:meta-messenger`
- `channel:whatsapp`
- `commerce:woocommerce`
- `commerce:shopify`
- `commerce:prestashop`
- `runtime:n8n`
- `database:supabase`

A skill teaches an agent how to operate an adapter; it does not become the
authorization boundary.

### 3. Plugins at the edges

OpenClaw's plugin model keeps optional capabilities at the edge while the
core exposes stable contracts.

This maps directly to our architecture:

```text
DDD/Application contracts
        ↓
Ports
        ↓
Adapters / plugins
        ↓
Provider APIs
```

### 4. Tool policy

OpenClaw filters tools through policy before the model can call them.

We should apply the same idea to our development/runtime agent surfaces:

```text
Agent
 ↓
Skill discovery
 ↓
Tool discovery
 ↓
Capability policy
 ↓
WF-10 authorization
 ↓
Adapter
```

Important: development-agent tool policy and customer-commerce authorization
are separate controls. Neither should replace WF-10.

### 5. Session/routing model

OpenClaw has explicit session routing and cross-agent controls.

We should apply this concept to:

- customer conversation sessions
- human-handoff sessions
- autonomous agent sessions
- engineering-agent sessions

Each session needs an explicit scope and owner.

## What we should NOT copy

Do not replace n8n with an OpenClaw-style agent loop.

The product requirement is different:

- n8n remains deterministic workflow orchestration.
- LLM remains proposal/reasoning.
- WF-10 remains authorization.
- Commerce platform remains commerce source of truth.
- Supabase remains durable domain/application state.
- Adapters isolate provider APIs.

OpenClaw's strongest contribution here is the **control-plane + tools + skills +
plugins + session architecture**, not its exact runtime implementation.
