# Repository Final Model Before Phase 12

```text
n8n-agent-ddd/
├── spec/                 # contracts, invariants, schemas, architecture, releases
├── .agents/              # canonical shared agent skills, policies and upstream refs
├── harness/              # Chief/PM/CTO/Dev/QA/Security orchestration
├── platform/             # ports, authorization, state, capabilities, audit
├── domains/              # bounded-context domain projects
├── contracts/            # platform/domain/action/event/external contracts
├── runtime/               # n8n, Supabase/Postgres profile, Redis, monitoring
├── infrastructure/       # Docker, production, blue/green, backups
├── tests/                 # architecture, security, integration, red-team, DR
├── scripts/               # validation, staging, readiness, production
├── docs/                  # maintainer architecture and operations
└── docs-user/             # operator/user documentation
```

## Data plane

```text
Domain
  ↓
Repository Port
  ↓
Drizzle
  ↓
PostgreSQL
  ├── RLS / policies / triggers / functions
  └── pgvector
```

Supabase is a supported/default platform profile over PostgreSQL.

## Agent control plane

```text
Chief Agent
  ↓
Skill discovery/router
  ↓
Tool policy
  ↓
Skills / Tools / Plugins / MCP
  ↓
Platform ports
  ↓
n8n
  ↓
WF-10 authorization
  ↓
WF-20 privileged adapter
```

## Runtime

```text
Channel
  ↓
WF-00..WF-20
  ↓
PostgreSQL durable state
  ↓
Commerce / Knowledge / Channel adapters
```

Compute is disposable. State is durable. Business rules are versioned. Execution is idempotent. Deployments are reversible.

## Before Phase 12

The remaining Phase 10 external evidence is intentionally still separate. Phase 11 implementation is not equivalent to production certification.
