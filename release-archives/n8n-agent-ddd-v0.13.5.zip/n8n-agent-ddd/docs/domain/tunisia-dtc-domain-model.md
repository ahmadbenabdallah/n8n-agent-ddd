# Tunisia DTC Domain Model

## Objective

Provide a concrete DDD reference domain for a Tunisia DTC business operating
through Messenger and WooCommerce.

## Bounded-context map

- Customer Identity — who the actor is and what they may access.
- Conversation — current interaction state and ownership.
- Commerce — product, cart, promotion, checkout and order concepts.
- Payment — transaction lifecycle and payment verification.
- Support — support decisions and escalation.
- Knowledge — approved business knowledge.
- Governance — authorization, audit, reconciliation and monitoring.

## Aggregate boundaries

`Customer`, `Conversation`, `Cart`, `Checkout/Order`, `Transaction`,
`Authorization`, and `Escalation` are separate aggregate boundaries.

The LLM is not an aggregate and has no domain authority.

## Domain-to-runtime mapping

| Domain capability | Runtime owner |
|---|---|
| Identity | WF-02 |
| Conversation state | WF-03 |
| Intent | WF-04 |
| Sales | WF-05 |
| Support | WF-06 |
| Order scope | WF-07 |
| Escalation | WF-08 |
| Reasoning | WF-09 |
| Authorization | WF-10 |
| Product | WF-11 |
| Cart | WF-12 |
| Promotion | WF-13 |
| Checkout | WF-14 |
| Transaction | WF-15 |
| Rendering | WF-16 |
| Audit | WF-17 |
| Knowledge | WF-18 |
| Monitoring/reconciliation | WF-19 |
| WooCommerce execution | WF-20 |
