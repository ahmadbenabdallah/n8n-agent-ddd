# Phase 6 — Tunisia DTC Domain

Phase 6 turns the reference Tunisia DTC domain into a formal DDD specification.

## Delivered

- bounded-context definition
- business rules
- entity and aggregate catalogs
- value objects
- commands and events
- policies and projections
- all WF-00 → WF-20 workflow specifications
- domain/workflow contract
- invariant test suite
- workflow contract matrix
- domain documentation

## Definition of Ready for implementation

A workflow is ready for implementation only when:

1. domain purpose is explicit
2. input/output contract exists
3. dependencies are known
4. authorization requirements are explicit
5. idempotency requirements are explicit
6. failure/reconciliation behavior is explicit
7. audit/observability requirements are explicit
8. acceptance tests exist

## Next phase

Phase 7 should implement the durable Supabase schema/migrations and contract
validation, then begin converting the workflow specifications into executable
n8n workflow artifacts.
