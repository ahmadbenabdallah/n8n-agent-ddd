# Tunisia DTC Workflow Contracts

Every workflow has a machine-readable contract under
`domains/tunisia-dtc/workflows/WF-XX/workflow.yaml`.

## Standard envelope

Each invocation carries:

- `correlation_id`
- `actor_context`
- `request_context`
- `domain_context`
- workflow/version metadata

Each workflow returns:

- status
- result
- emitted events
- audit reference

## Critical chain

`WF-09 proposal → WF-10 authorization → WF-20 execution → verification → WF-16 rendering → WF-17 audit → WF-19 monitoring`

The chain is intentionally asymmetric: reasoning can propose, authorization can
permit, and only the privileged gateway can execute.
