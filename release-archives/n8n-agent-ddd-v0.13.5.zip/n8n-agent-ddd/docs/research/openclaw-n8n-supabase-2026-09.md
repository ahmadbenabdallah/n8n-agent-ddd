# Research Notes — OpenClaw / n8n / Supabase

Research date: 2026-09-19

Primary references:

- OpenClaw Gateway architecture
- OpenClaw agent runtime architecture
- OpenClaw tools/skills/plugins documentation
- OpenClaw tool policy and permissions
- n8n official MCP documentation
- n8n official Skills repository
- Supabase Agent Skills documentation/repository

Key findings are summarized in:
`docs/architecture/openclaw-influenced-runtime.md`.

The research is architectural input, not a claim that these systems are
interchangeable with n8n Agent DDD.
