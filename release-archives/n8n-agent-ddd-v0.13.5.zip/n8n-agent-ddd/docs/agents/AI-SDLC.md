# AI-SDLC Operating Model

n8n-agent-ddd uses a gated lifecycle rather than direct prompt-to-code execution.

## Lifecycle

`DISCOVER → DEFINE → DOMAIN → SPECIFY → ARCHITECT → DESIGN → DECOMPOSE → PLAN → IMPLEMENT → TEST → SECURITY → REVIEW → INTEGRATE → DEPLOY → VERIFY → OPERATE → LEARN`

## Definition-of-Ready

Implementation begins only when the task has explicit requirements, acceptance criteria, domain impact, contracts, security assessment, test strategy, migration assessment and rollback strategy.

## Definition-of-Done

A task is complete only after implementation, tests, contracts, architecture invariants, security checks, documentation and migration/rollback requirements pass.

## Task graph

Tasks declare dependencies. The harness may dispatch independent tasks in parallel, preferably in isolated git worktrees. Cycles and unknown dependencies are hard failures.

## Checkpoints

Long-running autonomous work must persist lifecycle state outside an ephemeral agent session so execution can resume after interruption.
