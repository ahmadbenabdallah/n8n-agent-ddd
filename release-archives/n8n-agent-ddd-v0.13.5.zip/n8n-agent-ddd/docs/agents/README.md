# Agent Architecture

`AGENTS.md` is canonical. Claude and Codex are adapters. `.agents/skills/` is the shared skill library. `agent-manifest.yaml` declares the machine-readable agent contract. `harness/` validates and orchestrates the lifecycle.
