# Agent Execution Contract

Agents operate through the repository contract and harness.

A normal task produces:

1. task specification;
2. Definition-of-Ready evaluation;
3. selected skills;
4. implementation worktree;
5. validation/test evidence;
6. security review;
7. architecture review;
8. Definition-of-Done evaluation;
9. PR-ready result.

The agent does not self-authorize production deployment.
