# Agent Compatibility

The repository has one canonical contract (`AGENTS.md`) and one shared skill library (`.agents/skills/`). Claude Code and Codex are adapters.

| Capability | Core | Claude | Codex |
|---|---:|---:|---:|
| Canonical AGENTS.md | yes | yes | yes |
| Shared skills | yes | yes | yes |
| Agent manifest | yes | yes | yes |
| Harness validators | yes | yes | yes |
| Architecture/security gates | yes | yes | yes |
| Agent-specific hooks | n/a | adapter | adapter |

Adapters must invoke the same underlying policies and validators rather than maintaining duplicate policy engines.
