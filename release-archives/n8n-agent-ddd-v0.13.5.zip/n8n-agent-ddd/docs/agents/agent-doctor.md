# Agent Doctor Specification

`pnpm doctor` is a repository readiness check, not a substitute for CI.

Required checks:
- runtime prerequisites: Node, pnpm, Git;
- instruction discovery: AGENTS.md, Claude adapter, Codex adapter;
- agent manifest;
- skill tree and metadata;
- role tree;
- policy tree;
- platform/domain/runtime roots;
- validator availability.

Future versions add semantic instruction-conflict detection, skill routing tests, permission-policy validation, contract validation, architecture invariants and environment/runtime health checks.
