# Skill System

`.agents/skills/` is the canonical shared skill library.

A skill is an executable knowledge unit: it contains trigger metadata, a required sequence, safety rules and optional references/templates/validators.

## Rules

- Every skill has `SKILL.md`.
- Skill names are globally unique.
- Names use `namespace:capability`.
- Skills are selected by capability, not by agent brand.
- Claude and Codex consume the same canonical skills.
- External skills require license/provenance review before redistribution.
- A skill never grants authority that the repository policy does not grant.

## Routing

The harness will eventually resolve:

```text
task
  ↓
classification
  ↓
required capabilities
  ↓
minimum skill set
  ↓
skill execution
  ↓
validators
```

## Upstream

External skills are adapted only after license compatibility, version/commit and attribution are recorded in `THIRD-PARTY.md`.
