# Repository Validation

Validation is intentionally executable.

```bash
pnpm doctor
pnpm validate
pnpm test
```

The Agent Doctor verifies the repository contract, adapters, manifest, shared skills, agent roles, harness, platform, domains and runtime directories.

The skill validator checks `SKILL.md` metadata and duplicate skill names.

Future validation layers will add JSON Schema validation, dependency graph validation, architecture invariants, secret scanning, n8n workflow validation and deployment policy checks.
