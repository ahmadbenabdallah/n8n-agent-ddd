# Code of Conduct

Contributors are expected to participate respectfully, constructively and professionally. Harassment, discrimination, intimidation and personal attacks are not acceptable.
