# Internal Documentation Boundary

## Purpose

Keep public documentation useful and safe while retaining detailed engineering material internally.

## Public tree

`documentation/`

Published to ReadMe by:

`.github/workflows/readme-docs.yml`

Published path:

`./documentation`

## Internal tree

`docs/`

Never included in the ReadMe publishing job.

## Rules

A document belongs in `documentation/` when an external user/developer needs it to install, configure, develop, operate, or understand the public platform.

A document belongs in `docs/` when it contains:

- internal architecture details
- detailed evidence procedures
- private security test material
- internal operational runbooks
- implementation notes not intended for external users

## Change review

When moving or copying material from internal to public documentation, review for:

- secrets
- customer data
- private infrastructure
- internal endpoints
- internal credentials/access methods
- exploit payloads
- private evidence
- unpublished incidents

Do not publish internal content merely because it is technically useful.
