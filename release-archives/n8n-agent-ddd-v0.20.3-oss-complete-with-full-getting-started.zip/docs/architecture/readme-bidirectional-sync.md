# ReadMe bi-directional documentation architecture

## Goal

Phase 0.20.3 separates public documentation from the engine repository and prepares a dedicated `n8n-agent-ddd-docs` repository for ReadMe bi-directional Git Sync.

## Repository boundaries

`n8n-agent-ddd` remains the engine repository. It contains implementation, contracts, tests, infrastructure and internal engineering documentation.

`n8n-agent-ddd-docs` contains public documentation only. It is the Git endpoint connected to the ReadMe project.

## Sync model

```text
n8n-agent-ddd
      |
      | controlled public-doc bridge
      v
n8n-agent-ddd-docs <---- bi-directional ----> ReadMe
```

The public docs repository is deliberately separate so a ReadMe editor cannot expose files from the engine repository's private `docs/` tree.

## Initial connection

ReadMe's bi-directional Git Sync requires the repository to be empty when the connection is first established. The connection is therefore a manual provider setup step, not something this repository claims to have executed.

After the connection is established, ReadMe creates the synchronized documentation structure. Git changes and ReadMe editor changes then synchronize in both directions.

## Feature documentation bridge

Bi-directional ReadMe sync handles the public docs repository <-> ReadMe relationship. It does not automatically infer documentation changes from every engine-code change. When a feature or release requires public documentation changes, the engine repository uses a controlled bridge to propose changes in `n8n-agent-ddd-docs` for review.

## Security boundary

Only files intentionally classified as public documentation may cross the bridge. Internal `docs/`, runtime evidence, credentials, secrets, private infrastructure details and security-sensitive implementation material remain outside the public repository.

## Truth status

This phase is a repository and workflow foundation. It does not claim that the GitHub repository has been connected to ReadMe or that a live bidirectional synchronization has been successfully executed.
