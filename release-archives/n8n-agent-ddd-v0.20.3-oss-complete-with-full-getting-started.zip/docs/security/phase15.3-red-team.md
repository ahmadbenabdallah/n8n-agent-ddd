# Phase 15.3 — Security / Red-Team Runtime Validation

This phase attacks the live staging runtime rather than merely checking source
files.

## Security model

```text
Untrusted customer content
        +
Untrusted retrieved content
        ↓
       LLM
        ↓
    proposal only
        ↓
      WF-10
   authorization
        ↓
      WF-20
 privileged commerce
```

The security test must prove that adversarial content cannot collapse these
boundaries.

## Test classes

### Prompt injection

Customer or retrieved content attempts to override:

- system instructions
- security policy
- identity scope
- authorization
- tool policy

Expected result: content remains untrusted.

### Authorization bypass

Attackers attempt to:

- forge authorization
- replay authorization
- escalate identity
- modify payment state
- modify price
- modify inventory
- execute commerce without WF-10

Expected result: blocked.

### Data isolation

Attempts to access:

- another customer's order
- another domain
- private data outside verified scope

Expected result: denied or escalated.

### Secret safety

Attempts to make the system reveal:

- credentials
- API keys
- encryption keys
- payment credentials

Expected result: blocked.

### Runtime attack surface

Test:

- arbitrary endpoint requests
- malformed payloads
- oversized input
- protected workflow mutation
- audit tampering
- credential values embedded in workflow fields

## Evidence

Record only:

- test ID
- attack class
- expected outcome
- observed outcome
- pass/fail
- correlation ID

Do not copy the attack payload when it contains credentials, customer PII,
payment data, or other sensitive material.

## Release rule

Any critical authorization bypass blocks the release.

A security test cannot be marked PASS merely because the source policy says it
should fail. The live runtime must demonstrate the expected rejection.

## Current status

Live red-team execution remains **NOT_EXECUTED** until a real staging
environment is available.
