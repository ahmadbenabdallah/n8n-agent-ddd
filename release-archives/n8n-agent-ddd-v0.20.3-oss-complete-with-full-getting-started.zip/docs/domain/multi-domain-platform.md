# Multi-Domain Platform / Ecosystem

Phase 20 generalizes the platform beyond the Tunisia DTC reference domain.

## Domain packs

A domain pack contains the business model and domain-specific implementation while consuming reusable platform contracts. The pack owns its entities, aggregates, commands, events, policies, projections, workflows, knowledge, adapters, and tests.

The Tunisia DTC domain remains the reference implementation. Future packs can target domains such as Umrah or dental without copying the platform runtime.

## Independent axes

Channels and commerce providers are independent:

- Messenger + WooCommerce
- Messenger + Shopify
- WhatsApp + Shopify
- WhatsApp + PrestaShop
- Telegram + custom commerce
- Webchat + Shopify

The platform therefore exposes provider-neutral ports instead of coupling domain logic to one channel or commerce vendor.

## Isolation

Each domain requires a stable `domain_id` and scoped:

- n8n Project
- workflow namespace
- PostgreSQL/data scope
- knowledge namespace
- authorization scope
- audit scope

Cross-domain access is denied by default. An explicit cross-domain contract requires authorization and audit coverage.

## Adapter boundary

Provider IDs are references, not domain identity. Provider-specific paths and credentials stay inside adapters.

## Deployment profiles

Domain profiles describe runtime configuration without coupling the domain to a specific infrastructure provider. Secrets remain externally injected.

## Ecosystem direction

Phase 20 establishes the reusable platform layer; it does not claim that every future domain adapter or live multi-domain deployment is already implemented or certified.

The 0.x roadmap remains complete only after real operational evidence and certification work are performed; Phase 20 does not itself declare 1.0.
