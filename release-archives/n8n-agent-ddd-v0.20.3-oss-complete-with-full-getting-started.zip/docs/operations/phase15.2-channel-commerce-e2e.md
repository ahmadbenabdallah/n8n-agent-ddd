# Phase 15.2 — Real Channel + Commerce E2E

This phase exercises the actual staging path rather than isolated workflow
execution.

## Target path

```text
Customer channel
      ↓
WF-00 Inbound Gateway
      ↓
WF-01 Security
      ↓
WF-02 Identity
      ↓
WF-03 Conversation
      ↓
WF-04 Intent
      ↓
WF-09 LLM Reasoning
      ↓
WF-10 Authorization
      ↓
WF-20 Commerce
      ↓
Commerce verification
      ↓
WF-16 Response
      ↓
WF-17 Audit
```

The LLM proposes. It does not execute.

## Required scenarios

### Informational product question

No commerce mutation is allowed. The response must use verified product data.

### Add to cart

The request must produce an authorized action before the commerce adapter
mutates the cart. The final cart state is verified against the commerce
provider.

### Checkout

The live cart, price, inventory and applicable promotion must be revalidated
before execution.

### COD order

Creating an order is not equivalent to receiving payment. A newly created COD
order must remain `payment_status=not_paid` unless a separate verified payment
operation changes it.

### Invalid authorization

The commerce mutation must be blocked.

### Unknown external outcome

If the provider outcome is uncertain, the system reconciles before retrying.

### Private order request

Customer identity and order scope are separate. A request without sufficient
verification must be denied or escalated.

## Evidence

Each scenario records:

- correlation ID
- scenario ID
- requested action class
- authorization result
- provider result
- verification result
- response result
- audit result

Sensitive credentials and payment/customer data must never enter the evidence
artifact.

## PASS rule

An E2E scenario is PASS only when the complete expected chain is observed in
the live staging runtime.

No live execution was performed while generating this release artifact.
