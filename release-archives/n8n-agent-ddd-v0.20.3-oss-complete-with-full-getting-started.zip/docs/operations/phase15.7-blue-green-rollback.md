# Phase 15.7 — Blue/Green + Rollback Execution

## Objective

Turn the blue/green deployment and rollback contracts into an actual staging execution drill.

The exercise proves that a known-good blue runtime can coexist with a newly deployed green runtime, that green is verified before traffic is switched, and that traffic can be returned to blue under a controlled rollback.

## Required controls

```bash
export ALLOW_LIVE_BG=YES
export BLUE_GREEN_TARGET_ISOLATED=YES
export CONFIRM_BG=YES
```

Production execution is explicitly out of scope for this phase.

## Execution sequence

1. Capture blue baseline: runtime version, release manifest, database schema version, workflow inventory, health and smoke results.
2. Create a required database backup/recovery point.
3. Prepare green using the target release.
4. Apply only compatible expand migrations.
5. Deploy green.
6. Run health checks.
7. Run smoke tests.
8. Verify contracts and canonical WF-00..WF-20 inventory.
9. Switch traffic to green.
10. Observe green and capture runtime evidence.
11. Trigger the controlled rollback drill.
12. Switch traffic back to blue.
13. Drain green.
14. Verify blue health, workflow inventory, database compatibility and durable state.
15. Audit the release, traffic switch and rollback.
16. Validate sanitized evidence.

## Rollback rules

Rollback must target a known-good release.

A failed health check, failed smoke test, contract violation, migration incompatibility, or explicitly triggered rollback exercise must not result in blind retries or arbitrary state mutation.

Database rollback is not assumed to mean restoring an old database snapshot. The preferred path is forward-compatible/expand migration design. Destructive contract steps require explicit approval and a separately verified recovery path.

Unknown external commerce outcomes must be reconciled rather than replayed.

## Evidence

Capture:

- blue and green release identifiers
- timestamps
- health/smoke results
- workflow inventory
- migration/schema versions
- traffic switch timestamps
- rollback trigger and reason
- rollback completion timestamp
- post-rollback verification
- sanitized audit references

Do not capture secrets, credentials, customer private data, payment credentials, or raw provider tokens.

## Current status

This repository contains the execution contract and staging drill scripts. No live staging blue/green or rollback execution is claimed by this artifact. BG, ROLLBACK and MIGRATION_COMPATIBILITY remain `NOT_EXECUTED` until runtime evidence is captured.
