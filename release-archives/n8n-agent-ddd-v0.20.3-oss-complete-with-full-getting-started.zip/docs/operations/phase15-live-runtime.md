# Phase 15 — Live Runtime Evidence

Phase 15 changes the validation model from static architecture checks to
evidence captured from a real staging runtime.

## Runtime topology

```text
                 staging
                    │
        ┌───────────┴───────────┐
        │                       │
      n8n                    PostgreSQL
        │                       │
  21 workflows              durable state
        │
        ├── WF-01 Security
        ├── WF-10 Authorization
        ├── WF-20 Commerce
        └── WF-17 Audit
```

The first 0.15.0 gate is intentionally narrower than full E2E commerce.
Commerce/channel execution belongs to 0.15.2.

## Preconditions

- staging n8n is running
- n8n version matches the release manifest
- PostgreSQL is reachable
- domain project is initialized
- credentials are injected by the runtime environment
- 21 canonical workflow definitions are available
- test adapters are configured
- evidence output is writable

## Run

```bash
./scripts/integration/phase15-preflight.sh
```

If the environment is available:

```bash
ALLOW_LIVE_RUNTIME=YES ./scripts/integration/phase15-preflight.sh
```

The script refuses to claim PASS when the live runtime cannot be reached.

## Evidence

Evidence must contain only non-sensitive runtime facts:

- timestamps
- runtime versions
- health states
- workflow keys/counts
- project identifiers where non-sensitive
- test result identifiers

It must never contain credentials, encryption keys, payment data, or customer
PII.

## Certification rule

`PASS` means the corresponding evidence file exists and validates.

`NOT_EXECUTED` means the runtime was not available or the gate was not run.

`FAIL` means the runtime was tested and the assertion failed.

Never convert `NOT_EXECUTED` to `PASS`.
