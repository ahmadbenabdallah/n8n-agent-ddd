# Upgrade & Migration Lifecycle

## Goal

Upgrade the runtime without treating deployment as a single destructive event.

```text
PRECHECK
   ↓
BACKUP
   ↓
EXPAND
   ↓
DEPLOY
   ↓
MIGRATE
   ↓
VERIFY
   ↓
SWITCH
   ↓
DRAIN
   ↓
CONTRACT
   ↓
AUDIT
```

## Expand → migrate → contract

### Expand

Introduce additive changes first:

- new nullable columns
- new tables
- new indexes
- new event versions
- compatibility readers
- dual-read/dual-write paths where required

The old release must remain able to operate safely while the expanded schema is
present.

### Migrate

Backfill or transform data using a bounded, observable migration. The migration
must have a release identifier and evidence.

### Contract

Only remove legacy structures after the new release is verified and the
rollback window has been assessed.

Destructive changes must never be hidden inside an ordinary deploy.

## n8n upgrades

Pin the n8n version in the release manifest. Verify workflow compatibility,
credentials, community/custom nodes, and runtime components before traffic is
switched.

For source-controlled n8n environments, the platform should keep one-directional
promotion semantics and avoid push/pull patterns that can overwrite changes.
n8n's documentation explicitly warns about data loss risks when pushing and
pulling to the same instance. citeturn0search4

## Database migrations

Drizzle is the schema/migration tool for the application data plane.

Production migration requirements:

- backup verified
- migration plan reviewed
- bounded execution
- explicit destructive-change approval
- post-migration verification
- reconciliation where external state is involved

## Rollback

Rollback is not automatically synonymous with "run the previous SQL migration
backwards."

For additive migrations, application rollback may be safe while the expanded
schema remains.

For destructive migrations, use a forward fix or restore/recovery procedure
when reversal would be unsafe.

## Version matrix

Every release records at minimum:

- platform release
- n8n version
- database schema version
- domain contract version
- business/security policy versions
- LLM/prompt version
- knowledge-base version

## Current status

This is a foundation release. Live migration, upgrade, rollback, and disaster
recovery execution remain **NOT EXECUTED**.
