# Runtime Health

Runtime health is a control-plane signal, not a business authorization.

## Health model

```text
HEALTHY
DEGRADED
UNHEALTHY
UNKNOWN
MAINTENANCE
```

`UNKNOWN` is intentionally distinct from `UNHEALTHY`. Lack of evidence must not
be converted into a claim that the runtime is healthy or that a business
operation failed.

## Control loop

```text
Observe
  ↓
Classify
  ↓
Decide
  ↓
Act
  ↓
Verify
  ↓
Audit
  ↓
Learn
```

## Checks

### Process

- n8n reachability
- database reachability
- worker reachability

### Application

- project binding
- workflow inventory
- required workflow versions
- runtime configuration

### Data

- schema state
- durable state
- idempotency store
- reconciliation backlog

### Security

- protected workflow set
- authorization boundary
- secret presence without exposing secret values

## Upgrade-aware health

After a runtime upgrade, health checks must include:

1. release manifest comparison
2. schema version verification
3. workflow inventory verification
4. baseline health
5. reconciliation

A runtime that has not completed these checks must not be represented as
verified healthy.

## Current status

The commands in this release are policy/contract checks. Live runtime health
evidence remains **NOT EXECUTED**.
