# Phase 15.5 — Load + Resilience Runtime Validation

This phase measures how the staging runtime behaves under controlled load and
dependency failures.

## Principle

Load testing must prove more than throughput.

The system must remain inside its security, authorization, idempotency, and
data-integrity boundaries while under pressure.

## Profiles

```text
baseline
   ↓
steady state
   ↓
burst
   ↓
saturation
   ↓
recovery
```

The exact concurrency and duration are environment-specific and must be
configured before execution.

## Workloads

The suite covers:

- informational requests
- product lookup
- cart reads
- cart mutations
- support requests
- controlled test orders
- rejected authorizations
- reconciliation requests

Commerce mutations use a dedicated test adapter. Real payment and real
customer traffic are forbidden.

## Fault injection

Controlled failures include:

- n8n restart
- worker outage
- PostgreSQL connection pressure
- commerce timeout
- commerce 5xx
- channel timeout
- queue backlog
- transient network failure
- stale runtime lock

## Expected safety behavior

```text
Transient
   → bounded retry when safe

Unknown commerce outcome
   → reconcile before retry

Persistent failure
   → degrade / escalate

Authorization failure
   → block

Overload
   → backpressure / rejection
```

## Metrics

Capture:

- requests
- successful requests
- rejected requests
- error rate
- p50/p95/p99 latency
- concurrency
- queue/backlog indicators
- dependency failures
- recovery time
- duplicate mutation count
- authorization bypass count

Do not put secrets or sensitive customer/payment data into load-test evidence.

## Current status

No live load or fault-injection test was executed while generating this
release. All runtime gates remain **NOT_EXECUTED**.
