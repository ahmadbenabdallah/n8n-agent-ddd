# Phase 15.4 — Idempotency + Reconciliation

The objective is to prove that repeated requests and uncertain external
outcomes do not create duplicate business mutations.

## Mutation lifecycle

```text
REQUESTED
   ↓
AUTHORIZED
   ↓
EXECUTION_STARTED
   ↓
COMMERCE_MUTATION
   ↓
VERIFICATION
   ↓
COMPLETED
```

The durable idempotency record must survive runtime restarts.

## Duplicate requests

For a valid mutation:

```text
Request A ──────► mutation
Request B ──────► same idempotency key
                         │
                         └──► no second business mutation
```

The second request may receive the original result or a safe duplicate result,
according to the action contract.

## Unknown external outcome

A timeout after an external call does not prove that the provider rejected the
operation.

```text
local state: UNKNOWN
        ↓
   reconcile
   ┌────┼─────┐
   ↓    ↓     ↓
success failure unknown
   │      │      │
record  record   stop
success failure  + escalate
```

Blind retry is forbidden.

## Test cases

- duplicate cart mutation
- concurrent duplicate order
- replay after success
- cross-scope idempotency key
- provider timeout after mutation
- provider timeout before mutation
- successful reconciliation
- failed reconciliation
- unresolved reconciliation
- payment uncertainty
- authorization replay
- persistence after restart

## Critical distinction

Reconciliation answers:

> "What happened?"

It does **not** answer:

> "Are we allowed to do it?"

Authorization remains WF-10.

## Evidence

Only non-sensitive identifiers and outcome classes should be recorded.

No payment credentials, API keys, tokens, or raw customer PII belong in the
evidence set.

## Current status

Live idempotency and reconciliation execution remain **NOT_EXECUTED** until
the staging runtime and test commerce adapter are available.
