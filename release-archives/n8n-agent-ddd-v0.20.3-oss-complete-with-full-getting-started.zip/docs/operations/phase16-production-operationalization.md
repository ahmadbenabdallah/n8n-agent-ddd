# Phase 0.16 — Production Operationalization

## Purpose

Phase 0.15 established the evidence and certification framework. Phase 0.16 turns that framework into the repeatable operational path for a real staging runtime and, only after genuine certification, a controlled production deployment.

This phase is intentionally **execution-oriented**. It does not claim that a runtime exists merely because the repository contains deployment scripts.

## Lifecycle

`PREFLIGHT → PROVISION → CONFIGURE → SYNC → VERIFY → EXECUTE_EVIDENCE → CERTIFY → APPROVE → DEPLOY → VERIFY_PRODUCTION → OPERATE`

### 1. Preflight

Validate:

- pinned n8n version
- PostgreSQL availability
- runtime provider
- persistent volumes/state
- secret injection
- HTTPS/private access
- project binding
- required adapters
- backup capability

### 2. Configure

Runtime secrets must enter through the deployment environment or approved secret mechanism.

Never commit:

- `N8N_ENCRYPTION_KEY`
- API keys
- WooCommerce secrets
- database passwords
- channel credentials
- provider tokens

### 3. Synchronize

Use the existing n8n control-plane/MCP synchronization contract.

Canonical workflow identity remains:

`domain_id + workflow_key`

The expected Tunisia DTC set is exactly:

`WF-00 … WF-20`

Synchronization does not imply activation.

### 4. Execute evidence

Run the real Phase 15 suites against staging:

- integration
- 21 workflow execution
- channel/commerce E2E
- security/red-team
- idempotency/reconciliation
- load/resilience
- backup/restore
- blue/green/rollback
- drift/self-healing

Every result must reference actual runtime evidence.

### 5. Certify

Phase 15.9 must transition from `NOT_READY` to `CERTIFIED` only after all mandatory gates have valid evidence and required approvals.

### 6. Production

Production deployment is deliberately separate from certification.

Before traffic:

- release manifest verified
- backup verified
- health verified
- smoke verified
- rollback verified
- production preflight passed
- explicit operator approval recorded

No script in this phase automatically switches production traffic.

## Current status

The repository contains the operationalization contracts and executable preflight/sync/evidence orchestration foundation.

No live staging or production execution is claimed by this artifact.
