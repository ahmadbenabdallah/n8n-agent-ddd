# Phase 15.1 — 21 Workflow Execution

Phase 15.1 is the first release that treats the canonical workflow set as a
runtime inventory rather than only repository artifacts.

## Canonical set

```text
WF-00 Inbound Gateway
WF-01 Security Gate
WF-02 Customer Identity
WF-03 Conversation State
WF-04 Intent Router
WF-05 Sales Engine
WF-06 Support Engine
WF-07 Order Service
WF-08 Escalation Engine
WF-09 LLM Reasoning
WF-10 Action Authorization
WF-11 Product Service
WF-12 Cart Service
WF-13 Promotion Service
WF-14 Checkout Service
WF-15 Transaction/Payment
WF-16 Response Renderer
WF-17 Audit & Analytics
WF-18 Knowledge Base Ingestion
WF-19 Maintenance & Monitoring
WF-20 WooCommerce Gateway
```

## Verification

The live runtime must contain exactly the canonical set for the
`tunisia-dtc` project.

The test records:

- workflow key
- runtime workflow ID
- project binding
- active/inactive state
- version metadata where available
- execution result
- error result
- audit correlation

No credential values or customer/payment data are captured.

## Protected workflows

WF-01, WF-10, WF-15 and WF-20 are protected.

A successful inventory check does not grant permission to modify or activate
them.

## Execution strategy

Start with inventory-only mode.

Then run non-mutating smoke execution.

Controlled commerce mutation is outside the scope of this release and belongs
to the E2E release.

## PASS rules

A workflow is PASS only when its live execution evidence satisfies the
workflow's contract.

A missing workflow, duplicate canonical key, unexpected project binding, or
unexpected protected-workflow state blocks certification.

If the live n8n runtime is unavailable, the result remains `NOT_EXECUTED`.

## Current status

This artifact provides the live execution harness and evidence contract.
Actual staging execution was not performed during artifact generation.
