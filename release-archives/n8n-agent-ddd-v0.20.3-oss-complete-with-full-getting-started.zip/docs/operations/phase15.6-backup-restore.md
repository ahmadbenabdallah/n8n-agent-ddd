# Phase 15.6 — Backup / Restore Execution

## Objective

Turn the backup/restore contract from Phase 14.4 into an executable staging disaster-recovery drill.

The drill must prove that durable PostgreSQL state and the n8n persistent runtime state can be recovered into an isolated target, started with the same persistent `N8N_ENCRYPTION_KEY`, and validated without replaying unknown commerce mutations.

## Required controls

Before execution:

```bash
export ALLOW_LIVE_DR=YES
export RESTORE_TARGET_ISOLATED=YES
export CONFIRM_DR=YES
```

The production environment must never be used as the restore target in this phase.

## Drill

1. Run preflight.
2. Create a synthetic durable-state fixture and unique marker.
3. Create a PostgreSQL backup.
4. Verify the backup checksum and metadata.
5. Capture runtime manifest/state without secrets.
6. Provision an isolated restore target.
7. Restore PostgreSQL.
8. Restore n8n persistent data using the provider-specific snapshot/volume mechanism.
9. Inject the same persistent `N8N_ENCRYPTION_KEY`; never print it into evidence.
10. Start the restored runtime.
11. Verify database schema, n8n project binding, and the canonical 21 workflows.
12. Verify the synthetic durable-state marker.
13. Run reconciliation.
14. Run smoke tests.
15. Record measured RPO and RTO.
16. Validate evidence.

## RPO / RTO

RPO is measured from the latest recoverable backup point against the synthetic fixture timestamp.

RTO starts when restore execution begins and ends only after the restored runtime is healthy and the required smoke/reconciliation checks pass.

Do not estimate RPO/RTO from scripts. Record measured timestamps from the actual staging exercise.

## Evidence

Evidence may include:

- sanitized backup metadata
- checksum
- restore target identifier
- timestamps
- schema verification result
- project/workflow inventory result
- synthetic fixture verification
- reconciliation result
- smoke-test result
- measured RPO/RTO

Never include:

- secrets
- API keys
- passwords
- `N8N_ENCRYPTION_KEY`
- customer private data
- payment credentials
- full production exports

## Current status

This repository contains the execution contract and scripts. The current development environment does not provide the required live staging runtime, so the DR gate remains `NOT_EXECUTED` until the drill is actually performed.
