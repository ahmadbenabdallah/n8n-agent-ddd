# Phase 15.8 — Drift + Self-Healing Execution

## Objective

Execute the autonomous operations control loop against a real staging runtime:

`OBSERVE → CLASSIFY → DECIDE → ACT → VERIFY → AUDIT → LEARN`

The purpose is to prove that the runtime can detect controlled drift and perform only bounded operational remediation.

## Required controls

```bash
export ALLOW_LIVE_DRIFT=YES
export SELF_HEAL_TARGET_ISOLATED=YES
export CONFIRM_SELF_HEAL=YES
```

Production execution is explicitly out of scope.

## Drift exercise

Inject controlled, reversible staging drift in one or more of:

- workflow definition
- workflow activation state
- runtime configuration
- detectable schema/version state

The canonical Git-controlled definition must remain authoritative for platform artifacts.

The exercise must capture:

1. observed state
2. expected state
3. drift classification
4. decision
5. remediation action
6. resulting state
7. audit reference

## Self-healing exercise

Allowed remediation is deliberately narrow:

- restart a disposable worker
- perform a bounded retry of a transient internal operation
- clear a stale runtime lock
- reschedule reconciliation

Self-healing must never:

- authorize commerce
- change price or stock
- change payment status
- bypass WF-10
- retry an unknown commerce mutation blindly
- rotate or export secrets

## Human ownership

If an operator owns or is actively changing the affected runtime component, conflicting autonomous remediation must stop or defer.

## Verification

Every action requires post-action verification. A remediation that cannot be verified is not considered successful and must move to an incident/manual path.

## Evidence

Capture sanitized evidence for:

- drift injection
- observed/canonical comparison
- classification
- policy decision
- action
- verification
- audit event
- final reconciliation state

Never include secrets, credentials, API keys, customer private data, payment credentials, or provider tokens.

## Current status

This artifact provides the executable staging drill foundation. No live drift or self-healing execution is claimed here. DRIFT, SELF_HEAL, SAFETY and AUDIT remain `NOT_EXECUTED` until real staging evidence is captured.
