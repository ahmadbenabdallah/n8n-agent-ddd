# Reconciliation

Reconciliation resolves uncertainty between durable application state and
external providers.

## Core rule

**Reconcile before retry.**

This is especially important when a network failure occurs after a commerce
mutation may already have been accepted.

## Domains

Reconciliation may inspect:

- orders
- transactions
- carts
- authorizations
- idempotency records

## Outcomes

```text
RECONCILED_SUCCESS
RECONCILED_FAILURE
RECONCILED_UNKNOWN
HUMAN_REVIEW_REQUIRED
```

`RECONCILED_UNKNOWN` is a valid terminal evidence state for an automated cycle.
The system must not invent success or failure.

## What reconciliation cannot do

Reconciliation does not authorize a new commerce mutation.

Authorization remains the responsibility of **WF-10**.

Commerce execution remains the responsibility of **WF-20**.

## Self-healing interaction

If an operation has an unknown external outcome:

```text
UNKNOWN
  ↓
RECONCILE
  ├── known success → record success
  ├── known failure → record failure / safe retry if authorized
  ├── still unknown → stop + escalate
  └── conflict → human review
```

## Current status

This release defines the reconciliation contract and local policy checks.
Real provider reconciliation remains **NOT EXECUTED**.
