# ReadMe bi-directional sync operations

## One-time setup

1. Create an empty GitHub repository named `n8n-agent-ddd-docs`.
2. Do not initialize it with a README, license, `.gitignore`, or any other commit.
3. In ReadMe, open the Git Connection / Bi-Directional Sync settings.
4. Connect the ReadMe project to the empty repository.
5. Authorize the ReadMe GitHub App for that repository.
6. Let ReadMe create the initial synchronized content.
7. Pull the initial branch locally and apply the public documentation migration from the prepared docs artifact.
8. Run the ReadMe CLI lint/validation checks before merging documentation changes.

## Branches

ReadMe maps documentation versions/branches to Git branches. Branch names must match the corresponding ReadMe version names.

If GitHub branch protection or rulesets are enabled, configure the ReadMe Sync GitHub App according to the repository's protection model.

## Editing rules

- ReadMe editor changes are allowed for public documentation.
- Git changes are allowed through normal review workflows.
- Public documentation changes must not introduce secrets or internal implementation details.
- Engine-code changes do not automatically become public documentation without an intentional documentation update.

## Evidence

A future live verification should capture:

- GitHub repository connection
- ReadMe Git Connection status
- initial sync commit
- Git -> ReadMe update
- ReadMe -> Git update
- conflict handling behavior
- branch/version mapping

Until that evidence exists, the synchronization status remains `NOT_EXECUTED`.
