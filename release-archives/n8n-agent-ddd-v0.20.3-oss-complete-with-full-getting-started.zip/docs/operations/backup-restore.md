# Backup & Restore Operations

## Objective

Make runtime compute replaceable while preserving durable application state and
the ability to recover the n8n execution environment.

## Backup layers

### PostgreSQL

PostgreSQL is the primary durable application/data-plane backup.

```bash
./scripts/backups/create-postgres-backup.sh
./scripts/backups/verify-postgres-backup.sh <backup-file>
```

The scripts use `pg_dump` when available. They do not embed credentials in the
repository.

### n8n persistent data

The deployment provider must provide a persistent volume or equivalent snapshot
mechanism for runtime-local n8n data. The exact mechanism is provider-specific.

### Secrets

Secrets are injected by the deployment environment. They are not generated
from backup files and must not be stored in Git.

The n8n encryption key is a critical restore dependency. The same key must be
available when restoring encrypted n8n data.

## Restore sequence

```text
Provision
   ↓
Inject secrets
   ↓
Restore PostgreSQL
   ↓
Restore n8n persistent data
   ↓
Start runtime
   ↓
Readiness
   ↓
Project/workflow verification
   ↓
Reconciliation
   ↓
Smoke tests
   ↓
Traffic
```

## Important commerce rule

Restoring a database does not mean replaying historical commerce mutations.
If the restored state contains an operation whose external outcome is unknown,
the system must reconcile the external commerce provider before taking a new
mutation.

## Verification checklist

- [ ] backup artifact exists
- [ ] backup artifact integrity verified
- [ ] database restore completed
- [ ] schema/version verified
- [ ] required secrets injected
- [ ] n8n starts successfully
- [ ] project binding verified
- [ ] expected workflow inventory verified
- [ ] reconciliation completed
- [ ] smoke tests completed
- [ ] audit evidence captured
- [ ] traffic enabled only after verification

## Current status

This release provides the contract and local tooling. Real backup, restore,
and disaster-recovery execution remains **NOT EXECUTED**.
