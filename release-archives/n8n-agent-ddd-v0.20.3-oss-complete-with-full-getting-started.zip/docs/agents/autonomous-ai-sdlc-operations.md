# Autonomous AI-SDLC & Operations

Phase 19 extends Harness into a bounded multi-agent development and operations system.

## Topology
Chief Agent → PM, Architect/CTO, Security, Developers, QA, Reviewer.

The Chief orchestrates work; specialists own defined reasoning and review responsibilities. The customer-facing agent remains the n8n/domain runtime.

## Task graph
Every meaningful unit of work has durable identity, dependencies, owner, acceptance criteria, lifecycle state, and evidence references. Unsatisfied dependencies block execution.

## Isolated implementation
Developer agents use isolated Git worktrees. Integration uses repository review and CI. Coding agents do not SSH directly into production.

## Session management
Durable state contains task/session metadata, decisions, artifacts, blockers, and evidence references. Secret values and credential material are excluded.

## Bounded autonomy
Planning and scoped implementation can be autonomous. High-impact merges, production deployment, destructive migrations, credential operations, and sensitive runtime changes remain review-gated.

## Self-improvement
`OBSERVE → MEASURE → COMPARE → IDENTIFY GAP → PROPOSE CHANGE → REVIEW → TEST → ADOPT OR REJECT`

Changes require evidence plus regression/security validation. Authorization cannot be silently changed through self-improvement.

Phase 19 is a control-plane foundation and does not claim live multi-agent or autonomous production execution.
