# Phase 0.17 — Harness Control Plane

## Boundary

The Harness is the **developer/AI-agent control plane**.

It is not the deployed customer-facing agent and it is not a replacement for the n8n workflow editor.

The customer runtime remains:

`n8n + domain workflows + durable state + adapters + LLM reasoning + WF-10 authorization`

The native n8n dashboard remains the operator workflow UI.

## Harness interfaces

The initial control plane exposes:

```text
CLI
Skills
MCP
Git
CI
```

The CLI contract includes:

```bash
harness init
harness doctor
harness install
harness configure
harness develop
harness plan
harness test
harness security
harness validate
harness deploy
harness upgrade
harness rollback
harness status
harness run
```

## Agent hierarchy

Initial roles:

```text
Chief Agent
├── PM
├── Architect
├── Security
├── QA
├── Reviewer
└── Developer workers
```

Start small. The architecture supports additional workers without requiring a 100-agent deployment.

## Lifecycle

```text
PLANNED
→ ANALYZING
→ SPEC_READY
→ IMPLEMENTING
→ TESTING
→ SECURITY_REVIEW
→ ARCHITECTURE_REVIEW
→ READY_FOR_REVIEW
→ APPROVED
→ MERGED
→ DEPLOYED
→ VERIFIED
→ OPERATE
```

## Critical boundary

MCP capability discovery does not authorize an action.

A tool may be technically available while policy still denies its use.

The Harness cannot:

- authorize commerce
- bypass WF-10
- directly mutate protected commerce workflows
- export secrets
- switch production traffic without the required gates and approval

## Worktrees

Tasks should execute in isolated worktrees when parallel changes are required.

The canonical Git repository remains the engineering source of truth.

## Current status

This phase establishes the control-plane contracts and repository foundation. It does not claim that a complete autonomous multi-agent runtime is already implemented.
