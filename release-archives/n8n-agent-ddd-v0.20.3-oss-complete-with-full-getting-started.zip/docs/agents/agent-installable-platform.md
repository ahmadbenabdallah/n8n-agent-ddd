# Agent-Installable Platform

Phase 18 makes the repository installable and operable by Claude Code or Codex through the Harness control plane.

## Boundary

Harness is the developer/AI-agent control plane. It is not the customer-facing agent runtime and it is not a workflow editor. n8n's native dashboard remains the operator-facing workflow UI.

The customer runtime remains the n8n/domain runtime. Commerce authorization still terminates at WF-10 and privileged commerce execution remains behind WF-20.

## Installation contract

`harness install` is idempotent, environment-aware, provider-neutral, and safe to rerun. It prepares the local/control-plane prerequisites and delegates runtime-specific work to the existing deployment contracts.

## Bootstrap

A coding agent follows:

1. inspect the repository
2. verify Git and local prerequisites
3. run `harness doctor`
4. run `harness init`
5. configure non-secret values
6. validate configuration
7. run the appropriate test/security gates
8. use Git/CI deployment contracts for remote environments

Coding agents do not SSH directly into production.

## Command routing

The Phase 18 commands are thin control-plane entry points. They must reuse existing contracts and gates rather than duplicate business logic:

- `install` → installation contract
- `init` → repository/bootstrap contract
- `doctor` → prerequisite/configuration checks
- `configure` → runtime configuration/secrets contracts
- `develop` → development lifecycle
- `test` → test gates
- `security` → security/red-team gates
- `validate` → architecture/release validation
- `deploy` → production/deployment gates and explicit approval

## Secret safety

Doctor and configuration commands report presence/shape/status, never secret values. Production secrets remain deployment-managed and are not committed to Git or exposed to the agent unless a specific, policy-approved operation requires metadata about them.

## Production boundary

Production deployment remains blocked unless the required certification and operational gates are satisfied and an explicit approval is present. Phase 18 does not claim live production execution.
