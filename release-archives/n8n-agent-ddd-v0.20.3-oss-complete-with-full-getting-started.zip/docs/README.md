# Internal Engineering Documentation

This directory is **private/internal engineering documentation**.

It is intentionally excluded from the ReadMe publishing workflow.

## Contents

### Agent/control plane

- `docs/agents/harness-control-plane.md`
- `docs/agents/agent-installable-platform.md`
- `docs/agents/autonomous-ai-sdlc-operations.md`

These describe the Harness boundary, agent-installable platform, multi-agent topology, task state, bounded autonomy, and evaluation loop.

### Domain architecture

- `docs/domain/multi-domain-platform.md`

This covers domain packs, provider-neutral ports, channel/commerce independence, and cross-domain isolation.

### Operations

`docs/operations/` contains detailed operational and evidence procedures for:

- runtime health
- reconciliation
- backup/restore
- migrations/upgrades
- 0.15 runtime evidence
- security/red-team execution
- idempotency/reconciliation
- load/resilience
- disaster recovery
- blue/green rollback
- drift/self-healing
- certification
- production operationalization

### Security

`docs/security/` contains internal red-team/security execution material.

## Privacy rule

Do not publish this directory to ReadMe.

It can contain implementation-level details, internal evidence procedures, security test material, or operational information that is inappropriate for public documentation.
