#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"

test -f "$ROOT/spec/releases/phase-15.6-backup-restore-execution.yaml"
test -f "$ROOT/docs/operations/phase15.6-backup-restore.md"

for f in   scripts/disaster-recovery/phase15.6-preflight.sh   scripts/disaster-recovery/phase15.6-create-backup.sh   scripts/disaster-recovery/phase15.6-restore-drill.sh   scripts/disaster-recovery/phase15.6-verify-restore.sh   scripts/disaster-recovery/phase15.6-validate-evidence.sh
do
  test -x "$ROOT/$f"
done

grep -q 'production_restore: false' "$ROOT/spec/releases/phase-15.6-backup-restore-execution.yaml"
grep -q 'isolated_restore_required: true' "$ROOT/spec/releases/phase-15.6-backup-restore-execution.yaml"
grep -q 'same_n8n_encryption_key_required: true' "$ROOT/spec/releases/phase-15.6-backup-restore-execution.yaml"
grep -q 'status: "NOT_EXECUTED"' "$ROOT/spec/releases/phase-15.6-backup-restore-execution.yaml"

echo "Phase 15.6 contract: PASS"
echo "This is a repository contract check, not live DR evidence."
