# Runtime configuration and secrets

The platform intentionally separates four configuration classes.

## Infrastructure

Provider/deployment configuration:
- n8n URL
- database host
- ports
- webhook base URL

## Secrets

Injected by the deployment environment:
- n8n encryption key
- database password
- API credentials

Secrets are never stored in Git or business configuration.

## Application configuration

Durable business configuration belongs in PostgreSQL:
- currency
- COD policy
- support hours
- business feature flags
- domain-specific rules

## Provider configuration

Selects the deployment profile without changing the domain model.

### Encryption key rule

The n8n encryption key is persistent runtime state. It must remain stable across restarts, upgrades, blue/green deployments, and restoration of the n8n database/state. Changing it is a controlled migration event, not an ordinary configuration edit.
