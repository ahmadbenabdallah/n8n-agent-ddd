# Local runtime scaffold

The local profile is intentionally boring:

```text
Docker Compose
├── PostgreSQL 16
│   └── postgres_data
└── n8n 2.39.8
    └── n8n_data
```

n8n binds to `127.0.0.1:5678`, so the editor is not exposed on the LAN by default.

Commands:

```bash
./scripts/runtime/local-stack-doctor.sh
./scripts/runtime/local-stack-up.sh
./scripts/runtime/local-stack-status.sh
./scripts/bootstrap/wait-for-n8n.sh
```

Stopping the stack preserves named volumes:

```bash
./scripts/runtime/local-stack-down.sh
```

Destructive reset requires an explicit `RESET` confirmation:

```bash
./scripts/runtime/local-stack-reset.sh
```

For a VPS, replace localhost binding with the approved private-access mechanism. Tailscale is optional.
