# Phase 14 live runtime

Phase 14 is evidence-driven.

Run against a real deployment:

```bash
export N8N_BASE_URL=https://...
export N8N_API_KEY=...
./scripts/integration/run-live-suite.sh
```

The suite records JSONL evidence under `artifacts/runtime-evidence/`.

`PASS` means only that the specific command-backed check passed. A gate remains `NOT_EXECUTED` when the corresponding live fixture is unavailable.

The suite never stores API keys or other secret values in evidence.

## Current boundary

This harness verifies n8n readiness and authenticated API reachability first. Full INT/SEC/E2E/IDEMP/RECON/DRIFT certification requires configured test workflows and external-system fixtures.
