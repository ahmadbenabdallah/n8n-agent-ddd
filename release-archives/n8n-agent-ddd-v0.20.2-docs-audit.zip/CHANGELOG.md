# Changelog

## Unreleased

### Documentation

- Added a public user documentation tree under `documentation/`.
- Added developer guidelines for architecture, domains, n8n workflows, testing, security, AI agents, releases, and documentation.
- Added ReadMe publishing guidance.
- Added GitHub Actions automation to publish documentation to ReadMe from `main`.
- Clarified the separation between customer runtime, Harness control plane, n8n operator UI, and Git/CI source of truth.
## 0.20.2 — Documentation Boundary & Public Docs

### Added
- Curated public documentation under `documentation/`.
- Internal documentation index under `docs/README.md`.
- Internal 0.17–0.20 architecture evolution map.
- Documentation privacy/source-of-truth boundary.
- Public ReadMe publishing guidance.

### Changed
- Public docs now explicitly describe the customer runtime vs Harness control plane.
- Public docs cover installation, configuration, deployment, operations, domain packs, n8n workflows, AI agents, security, testing, and release processes.
- Internal docs remain excluded from the ReadMe CI publishing workflow.
