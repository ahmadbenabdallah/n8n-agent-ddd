# n8n Agent DDD

**Open-source, domain-driven autonomous agent runtime built around n8n.**

`n8n-agent-ddd` separates the customer-facing agent runtime from the developer/AI control plane used to build, test, validate, deploy, and operate it.

The reference implementation is a Tunisia DTC e-commerce sales/support agent using n8n, PostgreSQL/Supabase, a commerce adapter, channel adapters, and LLM reasoning.

## What this project provides

- Domain-driven agent architecture
- 21-workflow n8n runtime boundary
- Durable PostgreSQL application/domain state
- Explicit identity and authorization boundaries
- Commerce-provider adapters
- Channel-provider adapters
- Knowledge and observability ports
- Runtime backup, migration, reconciliation, and deployment contracts
- Harness control plane for developers and coding agents
- Multi-agent AI-SDLC foundation
- Multi-domain/domain-pack architecture
- Docs-as-code with ReadMe publishing through GitHub Actions

## Core runtime invariant

```text
LLM proposes
    ↓
n8n validates
    ↓
WF-10 authorizes
    ↓
WF-20 executes privileged commerce operation
    ↓
Commerce provider verifies
    ↓
WF-16 renders verified facts
    ↓
WF-17 audits
    ↓
WF-19 monitors/reconciles
```

The LLM is never the commerce authorization boundary.

## Two systems, deliberately separated

### Customer runtime

The deployed business agent is the n8n/domain runtime:

- n8n workflows
- domain policies
- LLM reasoning
- channel adapters
- commerce adapters
- PostgreSQL/Supabase state
- knowledge
- authorization
- audit and reconciliation

### Developer/AI control plane

Harness is used by developers and coding agents such as Claude Code or Codex:

```text
Claude Code / Codex
        ↓
     Harness
        ↓
 Skills / MCP / Git / CI
        ↓
 tests / security / validation / deployment
        ↓
     runtime
```

Harness is **not** the customer runtime and does not replace n8n's native workflow UI.

## Quick start

For users, start with the public documentation:

- `documentation/getting-started/`
- `documentation/installation/`
- `documentation/configuration/`
- `documentation/deployment/`
- `documentation/operations/`

For contributors:

- `documentation/development/`
- `documentation/development/architecture.md`
- `documentation/development/domain-development.md`
- `documentation/development/workflow-development.md`
- `documentation/development/testing.md`
- `documentation/development/security.md`
- `documentation/development/release-process.md`

## Harness

```bash
./scripts/harness/install.sh
./scripts/harness/init.sh
./scripts/harness/doctor.sh
./scripts/harness/configure.sh
./scripts/harness/develop.sh
./scripts/harness/test.sh
./scripts/harness/security.sh
./scripts/harness/validate.sh
./scripts/harness/deploy.sh
```

The commands are control-plane entry points. They must reuse existing gates rather than bypassing runtime policies.

## Security boundaries

- WF-10 is the hard commerce authorization boundary.
- WF-20 is the privileged commerce integration boundary.
- Customer/retrieved content cannot override system policy or permissions.
- Identity assurance cannot be promoted by the LLM.
- Private order/customer/payment information requires verified scope.
- Secrets are deployment-managed and are not committed to Git.
- Coding agents do not SSH directly into production.
- Unknown external mutation outcomes are reconciled instead of blindly retried.
- Capability discovery through MCP does not grant authorization.

## Documentation model

Git is the source of truth for documentation. ReadMe is the public publishing/hosting layer. Internal `docs/` content is not published.

The `documentation/` directory contains user-facing and developer-facing documentation. A GitHub Actions workflow publishes it to ReadMe after approved changes to `main`.

ReadMe's official `rdme` GitHub Action supports uploading Markdown from CI; ReadMe also documents bi-directional Git sync as an alternative for teams that want ReadMe and Git to be two-way synchronized.

## Project status

The repository has completed the architectural 0.17–0.20 foundation:

- 0.17 Harness Control Plane
- 0.18 Agent-Installable Platform
- 0.19 Autonomous AI-SDLC & Operations
- 0.20 Multi-Domain Platform / Ecosystem

These phases define contracts and scaffolding. They do **not** by themselves claim live production certification or autonomous production execution.

The next maturity step is real runtime evidence, operational execution, certification, and release hardening toward 1.0.
