## 0.12.9 — Operator Ownership & Runtime Binding

- Replaced the ambiguous customer terminology with an explicit operator ownership model.
- Defined platform, operator, n8n, secret-provider, and infrastructure ownership surfaces.
- Added operator roles for business configuration and permitted extension editing.
- Formalized n8n project/runtime binding without introducing a custom administration UI.
- Formalized upgrade preservation and incompatible-extension quarantine rules.
- Preserved WF-01, WF-10, WF-15, and WF-20 as platform-owned protected workflows.

# Changelog

## 0.12.3 — Autonomous Operations Control Loop

- Added executable observe/classify/decide control-loop policy.
- Added incident state machine with explicit transition validation.
- Added bounded exponential backoff for autonomous operational retries.
- Added LLM cost-budget evaluation with warning and hard-stop states.
- Hardened normalized drift hashing with recursive canonicalization.
- Added machine-readable incident and control-decision schemas.
- Added executable Phase 12 control-loop safety tests.
- Preserved the hard boundary: operational automation cannot authorize or mutate commerce.

## 0.1.0 — Foundation

Initial repository foundation: agent contract, adapters, manifest, skill structure, harness validators, DDD/runtime boundaries, OSS governance and GitHub CI/security skeleton.

## 0.3.0 — Agent Skills System

- Added canonical skill registry and validation contract.
- Added skill routing foundation and new DDD/n8n/security skills.
- Added Definition-of-Ready and Definition-of-Done lifecycle artifacts.
- Added execution-record schema and stronger skill validation.

## 0.4.0 — DDD Platform Foundation

- Added platform contracts for identity, authorization, durable state, idempotency and events.
- Added platform invariants and validation.
- Added reconciliation, audit and observability boundaries.
- Added Tunisia DTC bounded-context manifest and WF-00 through WF-20 registry.
- Added executable platform validation to the repository validation pipeline.

## 0.5.0 — n8n Runtime Foundation

- Added n8n-first runtime manifests and boundaries.
- Added Supabase durable-state runtime contract.
- Added Redis and reverse-proxy runtime foundations.
- Added local Docker Compose foundation.
- Added workflow specification schema.
- Added formal WF-10, WF-16 and WF-20 specifications for critical boundaries.
- Added release/deployment manifest and runtime validation.

## 0.9.0 — Phase 9 Staging Integration & Validation Foundation

- Added Phase 9 staging manifest and production-gate criteria.
- Added staging runtime environment contract and Docker Compose foundation.
- Added Supabase, WooCommerce, Meta Messenger, and LLM staging contracts.
- Added integration, E2E, red-team, and disaster-recovery test matrices.
- Added staging preflight, smoke, and evidence-runner commands.
- Added explicit evidence requirements for backup/restore, rollback,
  reconciliation, load, and workflow-drift validation.
- Production certification remains blocked until the required evidence is
  executed and reviewed.

## 0.10.0 — Production Readiness Evidence Foundation

- Added machine-readable evidence schema.
- Added production certification schema and deterministic readiness evaluator.
- Added workflow and contract verification commands.
- Added explicit production certification procedure and gate definitions.
- Certification remains BLOCKED until actual staging evidence and approvals exist.

## 0.10.1 — Multi-Channel / Multi-Commerce Adapter Architecture

- Added provider-neutral ChannelPort and CommercePort contracts.
- Added canonical commerce model and adapter registry.
- Added deployment profiles for Messenger/WooCommerce, WhatsApp/Shopify,
  WhatsApp/PrestaShop, and Webchat/Custom Commerce.
- Added DDD ports-and-adapters architecture guidance.
- Added adapter boundary architecture tests.
- Domain/application business logic remains independent from channel and
  commerce vendor APIs.

## 0.10.2 — OpenClaw-Inspired Control Plane & Independent Adapter Axes

- Clarified that channel and commerce adapters are independent.
- Added explicit valid combinations including Meta Messenger + Shopify.
- Added commerce-source-of-truth policy.
- Added OpenClaw-inspired gateway/session/tool-policy/skills/plugin design notes.
- Added production adapter lifecycle and capability negotiation.
- Added research notes for OpenClaw, n8n MCP/Skills, and Supabase Agent Skills.

## 0.10.3 — Data Plane & Architecture Reorganization

- Reframed Postgres as the portable durable data-plane contract.
- Made Supabase a supported/default platform profile rather than a domain dependency.
- Added Drizzle + PostgreSQL architecture guidance.
- Kept pgvector as the default KB/vector capability behind a port.
- Added knowledge fallback rules when a commerce adapter does not exist.
- Explicitly blocked KB from impersonating live transactional commerce state.
- Added independent domain profiles for commerce, knowledge-first, and hybrid domains.
- Added skill/MCP routing strategy for n8n, Supabase, Postgres, pgvector and adapters.
- Added migration/portability strategy and architecture tests.

## 0.10.4 — Domain Projects & n8n Isolation Model

- Added domain-project packaging and lifecycle.
- Added one-domain-per-n8n-project model.
- Added domain-scoped workflow namespaces, credentials, Postgres state and KB.
- Added cross-domain communication contracts and deny-by-default rules.
- Added n8n source-control/promotion model aligned with current n8n environments.
- Corrected commerce-unavailable behavior to assisted commerce: collect,
  escalate and hand off rather than ending the conversation.
- Preserved KB as the knowledge source, never as transactional commerce truth.

## 0.10.5 — Phase 10 Execution Foundation

- Added the executable Phase 10 staging runbook and command runner.
- Added evidence-run initialization and gate command mapping.
- Added domain-aware Phase 10 execution configuration.
- Added operator staging checklist.
- Production certification remains BLOCKED until external staging evidence is executed.


## 0.12.4 — Local Runtime Bootstrap Foundation

- Added a local runtime bootstrap contract.
- Added environment safety guards for local startup.
- Added deterministic discovery/validation of the expected 21 workflow directories.
- Added explicit n8n synchronization entry point.
- Added local runtime documentation.
- IMPORTANT: real n8n workflow API import/update is NOT implemented yet; the adapter stops before mutation and reports this explicitly.


## 0.12.5 — Runtime & Release Control Plane Foundation
- Corrected the architecture to distinguish n8n Skills/MCP from deterministic CI/CD.
- Added runtime/release/persistence contracts.
- Added release manifest generation and structural verification.
- Added a production gate that rejects unsigned manifests.
- Added initial GitHub CI/release workflow skeletons.
- IMPORTANT: cryptographic signing, live n8n MCP execution, live staging deployment, backup/restore execution, and production certification are NOT claimed complete.


## 0.12.6 — Concrete Local Runtime Foundation
- Added real local Docker Compose definitions for PostgreSQL and n8n.
- Added persistent named volumes for local PostgreSQL and n8n state.
- Added exact n8n image pin and explicit upgrade policy.
- Added local environment bootstrap and runtime health/doctor scripts.
- Added n8n MCP control-plane contract without embedding an unverified MCP implementation.
- Updated local runtime documentation with the honest workflow synchronization boundary.
- IMPORTANT: live n8n workflow synchronization via MCP has NOT been executed or certified.


## 0.12.7 — n8n MCP Workflow Control Integration
- Updated the pinned local n8n version to stable `2.39.8`, verified from the official n8n release feed on 2026-09-19.
- Added an explicit n8n instance-level MCP configuration example.
- Added the MCP workflow synchronization protocol.
- Added a deterministic desired-state sync-plan generator for WF-00..WF-20.
- Kept MCP as the agent control interface and CI/CD as deterministic release control.
- IMPORTANT: no live MCP session or workflow mutation was executed in this environment.

## 0.12.8 — Customer Runtime Configuration & Extension Layer

- Added durable customer business configuration contracts and optimistic versioning model.
- Added customer extension registry/lifecycle and compatibility contracts.
- Protected WF-01, WF-10, WF-15, and WF-20 from customer extension replacement.
- Added PostgreSQL persistence for configuration, extensions, and configuration changes.
- Added explicit ownership model for platform core, customer configuration, extensions, secrets, and infrastructure.
- Added Phase 12.8 architecture validation.
- Does not claim live n8n MCP/UI or production migration execution.

## 0.13.0 - Provider-Neutral Runtime Deployment

- Formalized local-all, n8n-remote, VPS-all, and managed-provider deployment modes.
- Added provider-neutral runtime contract.
- Added n8n-only Docker Compose runtime for VPS/container providers.
- Added local and remote deployment configuration examples.
- Added runtime configuration validation and provider contract tests.
- Documented separation of infrastructure, n8n runtime, domain configuration, and secrets.
- Confirmed n8n remains the native operator workflow UI; no replacement workflow editor is introduced.
