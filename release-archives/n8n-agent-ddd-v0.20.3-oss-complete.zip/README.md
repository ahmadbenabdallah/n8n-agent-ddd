# n8n Agent DDD

**Open-source, domain-driven autonomous agent runtime built around n8n.**

[![Status](https://img.shields.io/badge/status-active%20development-orange)](#project-status)
[![Version](https://img.shields.io/badge/version-0.20.3-blue)](#release-line)
[![License](https://img.shields.io/badge/license-Apache--2.0-green)](#license)

n8n Agent DDD is an open-source platform for building **domain-driven autonomous business agents** around n8n.

It combines:

- domain-driven design
- deterministic workflow orchestration
- LLM reasoning
- explicit authorization boundaries
- durable application state
- channel and commerce adapters
- knowledge and retrieval
- audit and reconciliation
- production deployment controls
- an AI-native software development lifecycle
- a developer/AI control plane called **Harness**

The first concrete reference implementation is a **Tunisia DTC e-commerce AI Sales & Support Assistant**.

> **LLM proposes → n8n validates → WF-10 authorizes → WF-20 executes → commerce provider verifies → WF-16 renders → WF-17 audits → WF-19 monitors.**

---

## Table of Contents

- [What is n8n Agent DDD?](#what-is-n8n-agent-ddd)
- [Why it exists](#why-it-exists)
- [Core principles and invariants](#core-principles-and-invariants)
- [Architecture](#architecture)
- [Repository structure](#repository-structure)
- [Tunisia DTC reference implementation](#tunisia-dtc-reference-implementation)
- [The 21-workflow architecture](#the-21-workflow-architecture)
- [Domain-driven design](#domain-driven-design)
- [Security model](#security-model)
- [Multi-channel and multi-commerce](#multi-channel-and-multi-commerce)
- [Harness and AI-SDLC](#harness-and-ai-sdlc)
- [State, idempotency and reconciliation](#state-idempotency-and-reconciliation)
- [Installation](#installation)
- [Quick start](#quick-start)
- [Development](#development)
- [Testing and evidence](#testing-and-evidence)
- [Deployment and operations](#deployment-and-operations)
- [Documentation and ReadMe](#documentation-and-readme)
- [Release line and roadmap](#release-line-and-roadmap)
- [Contributing](#contributing)
- [Security](#security)
- [Governance](#governance)
- [Code of Conduct](#code-of-conduct)
- [Support](#support)
- [Changelog](#changelog)
- [License](#license)
- [Acknowledgements](#acknowledgements)

---

## What is n8n Agent DDD?

n8n Agent DDD is designed around a simple separation of responsibilities:

```text
                    Developer / AI Agent
                            │
                     Claude / Codex
                            │
                      Skills + MCP
                            │
                            ▼
                       ┌─────────┐
                       │ Harness │
                       └────┬────┘
                            │
                     Git / CI / Gates
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                       n8n Agent DDD                          │
│                                                             │
│  Contracts · Platform · Domains · Policies · Tests          │
└──────────────────────────────┬──────────────────────────────┘
                               │
                               ▼
                         ┌───────────┐
                         │    n8n    │
                         │  Runtime  │
                         └─────┬─────┘
                               │
             ┌─────────────────┼─────────────────┐
             ▼                 ▼                 ▼
        PostgreSQL/           LLM          External adapters
        Supabase                         Commerce / Channels
```

The project deliberately separates the **customer runtime** from the **developer/AI control plane**.

### Customer runtime

The deployed business agent consists of:

- n8n workflows
- domain rules and policies
- LLM reasoning
- channel adapters
- commerce adapters
- PostgreSQL/Supabase-backed durable state
- knowledge
- authorization
- audit
- reconciliation
- monitoring

### Developer/AI control plane

Harness is used by developers and AI coding agents such as Claude Code and Codex to:

- inspect the repository
- plan work
- implement changes
- run tests
- run security checks
- validate architecture
- manage worktrees
- prepare releases
- deploy through controlled gates
- operate and verify the runtime

**Harness is not the customer-facing agent runtime and does not replace n8n's native workflow dashboard.**

---

## Why it exists

Many AI-agent implementations reduce the system to:

```text
LLM + prompt + tools
```

That model becomes fragile when the agent must perform real business operations.

A production business agent also needs explicit answers to:

- Who is this customer?
- What data is this customer allowed to access?
- Which business action is actually authorized?
- Where does current product/price/stock truth come from?
- What happens when an external API times out after a mutation?
- How do we prevent duplicate orders?
- How do we reconcile unknown outcomes?
- How do we audit consequential actions?
- How do we deploy and roll back safely?
- How do we isolate domains?
- How do AI coding agents modify the system without bypassing controls?

n8n Agent DDD treats those concerns as **architecture and contracts**, not as prompt instructions alone.

---

# Core principles and invariants

### 1. Compute is disposable. State is durable.

n8n is the orchestration/runtime layer. Critical business state belongs in durable PostgreSQL/Supabase-backed storage.

### 2. The LLM is not an authorization system.

The LLM can reason and propose structured actions. It cannot authorize itself.

### 3. WF-10 is the hard commerce authorization boundary.

Only the authorized branch may establish that a consequential commerce action is permitted.

### 4. WF-20 is the privileged commerce boundary.

Commerce mutations are executed through the controlled commerce gateway and verified against the provider.

### 5. Order creation is not payment.

Creating an order does not imply that payment succeeded. For example, a newly created COD order remains `not_paid` until the actual payment state changes.

### 6. Unknown outcomes are reconciled.

If an external mutation times out after execution may have started, the system does not blindly retry. It reconciles the external state.

### 7. Identity cannot be promoted by the LLM.

Identity assurance is established by application logic:

```text
ANONYMOUS
  ↓
CHANNEL-LINKED
  ↓
COMMERCE-MATCHED
  ↓
ORDER-VERIFIED
  ↓
HIGH-ASSURANCE
```

### 8. Capability discovery is not authorization.

MCP visibility, tool discovery, workflow access or skill availability does not grant business permission.

### 9. Human ownership blocks conflicting automation.

When a human operator owns a case or action, conflicting autonomous execution is blocked.

### 10. Deployments are reversible.

Database migrations, runtime changes and traffic switches require verification and a rollback strategy.

### 11. Evidence determines maturity.

A repository contract is not the same thing as a live runtime test. Production certification requires captured runtime evidence.

---

# Architecture

The platform is organized into reusable layers.

```text
┌───────────────────────────────────────────────────────────┐
│                       AI / Developer                      │
│                 Claude Code · Codex · Agents              │
└───────────────────────────┬───────────────────────────────┘
                            │
                     Skills / MCP / Git
                            │
                            ▼
┌───────────────────────────────────────────────────────────┐
│                         Harness                           │
│  Planning · Tasks · Worktrees · Gates · Validation        │
└───────────────────────────┬───────────────────────────────┘
                            │
                            ▼
┌───────────────────────────────────────────────────────────┐
│                    Platform Contracts                      │
│ Identity · Authorization · State · Events · Audit         │
│ Reconciliation · Observability · Domain Isolation         │
└───────────────────────────┬───────────────────────────────┘
                            │
                            ▼
┌───────────────────────────────────────────────────────────┐
│                         Domain                            │
│ Entities · Aggregates · Policies · Commands · Events      │
│ Projections · Workflows · Knowledge · Adapters             │
└───────────────────────────┬───────────────────────────────┘
                            │
                            ▼
┌───────────────────────────────────────────────────────────┐
│                         n8n Runtime                        │
│                     Workflow orchestration                 │
└───────────────────────────┬───────────────────────────────┘
                            │
             ┌──────────────┼──────────────┐
             ▼              ▼              ▼
        PostgreSQL          LLM       External providers
        / Supabase                    Commerce / Channels
```

### Runtime execution boundary

```text
Customer
   ↓
Channel
   ↓
WF-00 Inbound Gateway
   ↓
WF-01 Security Gate
   ↓
WF-02 Identity
   ↓
WF-03 Conversation State
   ↓
WF-04 Intent Router
   ↓
Sales / Support
   ↓
WF-09 LLM Reasoning
   ↓
WF-10 Action Authorization
   ↓
WF-20 Privileged Commerce Gateway
   ↓
Commerce Provider
   ↓
WF-16 Response Renderer
   ↓
WF-17 Audit
   ↓
WF-19 Monitoring / Reconciliation
```

---

# Repository structure

The main repository is the **engine and engineering source repository**.

```text
n8n-agent-ddd/
│
├── spec/                 # Formal platform, domain, lifecycle and release contracts
│
├── .agents/              # Shared agent skills, policies, references and workflows
│
├── codex/                # Codex roles, commands and configuration
│
├── claude/               # Claude agents, commands and hooks
│
├── harness/              # Developer/AI control plane
│
├── platform/             # Reusable runtime/platform capabilities
│
├── domains/              # Business domain packs
│   └── tunisia-dtc/      # Reference domain
│
├── contracts/            # Platform/domain/action/event/external contracts
│
├── runtime/              # n8n, PostgreSQL/Supabase, monitoring and evidence
│
├── infrastructure/       # Docker, environments, deployment and backups
│
├── tests/                # Architecture, integration, security, DR, E2E, etc.
│
├── scripts/              # Bootstrap, validation, migration and operations
│
├── docs/                 # Internal engineering documentation
│
└── documentation/        # Curated public documentation snapshot/bridge
```

### Internal vs public documentation

```text
docs/
└── Internal
    architecture
    security procedures
    operational runbooks
    evidence procedures
    engineering notes

documentation/
└── Public
    getting started
    installation
    configuration
    development
    deployment
    operations
```

The dedicated `n8n-agent-ddd-docs` repository is the public Git endpoint intended for ReadMe bi-directional synchronization.

---

# Tunisia DTC reference implementation

The first concrete domain is a **Tunisia DTC e-commerce AI Sales & Support Assistant**.

It demonstrates how the platform handles:

- customer conversations
- Tunisian Arabic / Tounsi
- Arabic, French and English
- mixed Tounsi/French/English
- Latin-transliterated Arabic
- product discovery
- product recommendations
- sales objections
- cart assistance
- checkout
- COD orders
- order support
- promotions
- knowledge retrieval
- human escalation
- identity and privacy
- authorized commerce actions
- audit and reconciliation

A typical deployment can connect:

```text
Customer
   │
   ▼
WhatsApp / Instagram / Facebook / Webchat
   │
   ▼
n8n Agent Runtime
   │
   ├── PostgreSQL / Supabase
   ├── LLM provider
   ├── Knowledge base
   └── Commerce adapter
           │
           ▼
       WooCommerce
```

The Tunisia DTC implementation is a **reference domain**, not a restriction on the platform. The multi-domain architecture is intended to support additional domain packs such as Umrah, dental and other business domains.

---

# The 21-workflow architecture

The 21 workflows are the reference runtime architecture for the **Tunisia DTC AI Sales & Support Assistant**.

They demonstrate how a real business agent can separate inbound handling, security, identity, conversation state, reasoning, authorization, commerce execution, response rendering and operations.

| ID | Workflow | Tunisia DTC responsibility |
|---|---|---|
| WF-00 | Inbound Gateway | Receive and normalize customer/channel events |
| WF-01 | Security Gate | Apply deterministic security and input controls |
| WF-02 | Customer Identity | Resolve and maintain customer identity context |
| WF-03 | Conversation State | Maintain durable conversation state |
| WF-04 | Intent Router | Route sales, support, order and other intents |
| WF-05 | Sales Engine | Product discovery, recommendations and sales flows |
| WF-06 | Support Engine | Customer support and issue-resolution flows |
| WF-07 | Order Service | Authorized order retrieval and operations |
| WF-08 | Escalation Engine | Human handoff and ownership transitions |
| WF-09 | LLM Reasoning | Produce grounded reasoning and structured proposals |
| WF-10 | Action Authorization | Enforce the hard authorization boundary |
| WF-11 | Product Service | Product/catalog retrieval |
| WF-12 | Cart Service | Cart reads and authorized cart mutations |
| WF-13 | Promotion Service | Validate and apply promotion rules |
| WF-14 | Checkout Service | Checkout preparation and orchestration |
| WF-15 | Transaction / Payment | Transaction state and payment handling |
| WF-16 | Response Renderer | Render verified results for the customer |
| WF-17 | Audit & Analytics | Record auditable business/security events |
| WF-18 | Knowledge Base | Ingest and maintain approved knowledge |
| WF-19 | Maintenance & Monitoring | Health, reconciliation and operational control loop |
| WF-20 | WooCommerce Gateway | Privileged WooCommerce integration boundary |

### The critical execution invariant

```text
LLM proposes
    ↓
n8n validates
    ↓
WF-10 authorizes
    ↓
WF-20 executes
    ↓
WooCommerce verifies
    ↓
WF-16 renders verified facts
    ↓
WF-17 audits
    ↓
WF-19 monitors and reconciles
```

The LLM cannot directly execute commerce mutations, set final prices, change inventory, declare payment success, bypass authorization or access arbitrary endpoints.

---

# Domain-driven design

The platform separates business logic from infrastructure and provider-specific implementation.

```text
Domain
  ↓
Platform contracts
  ↓
Ports
  ↓
Adapters
  ↓
Infrastructure
```

A domain pack can contain:

```text
domain/
├── business/
├── entities/
├── aggregates/
├── value-objects/
├── commands/
├── events/
├── policies/
├── projections/
├── workflows/
├── knowledge/
├── adapters/
└── tests/
```

Provider-specific IDs are references, not domain identity. Provider-specific credentials and implementation details remain inside adapters.

---

# Security model

Security is an architectural property, not a prompt-only feature.

## Authorization

```text
LLM proposal
      ↓
n8n validation
      ↓
WF-10 authorization
      ↓
authorized action
      ↓
WF-20 execution
      ↓
provider verification
```

Only the authorized branch may establish `execution_allowed=true`.

## Identity and privacy

The LLM cannot promote identity.

Order access is narrower than customer identity, and sensitive order/customer/payment data requires verified scope.

## Sensitive data

The following must never be placed into LLM or customer-visible context:

- PAN
- CVV
- OTP
- PIN
- passwords
- API keys
- provider secrets
- WooCommerce credentials/secrets
- cart tokens/nonces

Secrets are deployment-managed and excluded from:

- Git
- agent durable state
- prompts
- logs
- evidence artifacts
- doctor/status output
- customer messages

## Prompt injection

Customer messages, retrieved content, conversation history and external tool text are treated as untrusted unless explicitly designated as trusted structured data.

Retrieved content cannot override:

- system policy
- authorization
- identity scope
- security rules
- business rules

## High-risk escalation

Automation stops or escalates for cases such as:

- payment disputes or chargebacks
- legal threats
- serious unresolved complaints
- identity uncertainty for sensitive actions
- unauthorized-action requests
- security incidents
- repeated failed resolution
- human-owned cases

---

# Multi-channel and multi-commerce

Channels and commerce providers are independent axes.

```text
                 Domain
                   │
          ┌────────┴────────┐
          │                 │
       Channel           Commerce
          │                 │
     WhatsApp            WooCommerce
     Messenger            Shopify
     Instagram            PrestaShop
     Telegram             Custom
     Webchat
```

Core ports:

```text
ChannelPort
CommercePort
IdentityPort
PaymentPort
KnowledgePort
ObservabilityPort
```

This allows combinations such as:

```text
Messenger + WooCommerce
Messenger + Shopify
WhatsApp + Shopify
WhatsApp + PrestaShop
Telegram + Custom Commerce
Webchat + Shopify
```

The platform should not embed one provider into the domain model.

---

# Harness and AI-SDLC

Harness is the developer/AI control plane.

```text
Claude Code / Codex
        ↓
      Skills
        ↓
       MCP
        ↓
     Harness
        ↓
   Git / CI / Gates
        ↓
Runtime / n8n / infrastructure
```

The agent topology is:

```text
Chief
├── PM
├── Architect / CTO
├── Security
├── Developers
├── QA
└── Reviewer
```

The AI-SDLC lifecycle is:

```text
DISCOVER
→ DEFINE
→ DOMAIN
→ SPECIFY
→ ARCHITECT
→ DESIGN
→ DECOMPOSE
→ PLAN
→ IMPLEMENT
→ TEST
→ SECURITY
→ REVIEW
→ INTEGRATE
→ DEPLOY
→ VERIFY
→ OPERATE
→ LEARN
```

Agents use isolated worktrees and durable task state.

### Bounded autonomy

Agents may autonomously:

- inspect
- plan
- implement scoped changes
- run tests
- run security checks
- prepare releases
- propose improvements

High-impact actions remain review-gated, including:

- production deployment
- destructive migrations
- credential operations
- sensitive runtime changes
- authorization-policy changes

Agents must never:

- SSH directly into production
- bypass CI
- bypass WF-10
- silently weaken security
- access production secrets by default
- claim execution without evidence

---

# State, idempotency and reconciliation

Critical business state is durable.

Examples include:

```text
customer_identity
conversation
conversation_state
carts
cart_items
actions
authorizations
order_scope
orders
transactions
escalations
audit_events
idempotency_keys
knowledge
```

Consequential mutations require idempotency.

A mutation follows the conceptual lifecycle:

```text
REQUESTED
    ↓
AUTHORIZED
    ↓
EXECUTION_STARTED
    ↓
COMMERCE_MUTATION
    ↓
VERIFICATION
    ↓
COMPLETED
```

Unknown external outcomes require reconciliation rather than blind retry.

The operational control loop is:

```text
OBSERVE
→ CLASSIFY
→ DECIDE
→ ACT
→ VERIFY
→ AUDIT
→ LEARN
```

Self-healing is bounded. It may restart disposable workers, retry safe transient failures within limits, clear stale locks or reschedule reconciliation.

It may not authorize commerce, change prices/stock/payment state, bypass WF-10, or blindly retry an unknown mutation.

---

# Installation

The platform is provider-neutral.

Architectural deployment profiles include:

```text
local
    PostgreSQL + n8n in Docker

n8n_remote
    n8n hosted separately + external PostgreSQL

vps_all
    n8n + PostgreSQL on a VPS

managed_provider
    n8n container + managed/external PostgreSQL
```

Docker is the packaging boundary. Providers are adapters.

### Prerequisites

For local development:

- Git
- Bash
- Node.js
- pnpm
- Docker
- Docker Compose

Production additionally requires durable PostgreSQL, persistent n8n data, HTTPS, backup storage, deployment-managed secrets and controlled operator access.

Installation is not production certification.

---

# Quick start

The intended Harness entry points are:

```bash
harness init
harness doctor
harness install
harness configure
harness develop
harness test
harness security
harness validate
harness deploy
harness status
```

The repository also contains phase-specific scripts under:

```text
scripts/
├── harness/
├── integration/
├── security/
├── deployment/
├── disaster-recovery/
├── migrations/
├── operations/
└── production/
```

Use the public documentation for the current installation path and the internal documentation for engineering/operational procedures.

> **Important:** commands and contracts are not proof of live runtime execution. Runtime claims require captured evidence.

---

# Development

A typical change follows:

```text
DISCOVER
   ↓
SPECIFY
   ↓
ARCHITECT
   ↓
IMPLEMENT
   ↓
TEST
   ↓
SECURITY REVIEW
   ↓
ARCHITECTURE REVIEW
   ↓
CI
   ↓
MERGE
```

Changes should preserve:

- domain boundaries
- authorization invariants
- provider neutrality
- domain isolation
- idempotency
- auditability
- backwards compatibility
- evidence requirements

Business logic should live in domain/policy layers rather than being hidden inside provider-specific workflow nodes.

---

# Testing and evidence

Testing is organized into multiple levels:

```text
tests/
├── architecture/
├── certification/
├── disaster-recovery/
├── documentation/
├── harness/
├── integration/
├── operations/
├── platform/
├── production/
└── security/
```

The project distinguishes:

1. repository contract
2. local execution
3. staging execution
4. captured certification evidence
5. production verification

A passing contract test does **not** imply that a real staging or production runtime has passed.

The production certification framework covers areas including:

- runtime integration
- 21-workflow execution
- channel/commerce E2E
- security/red-team testing
- idempotency
- reconciliation
- load/resilience
- backup/restore
- blue/green deployment
- rollback
- drift detection
- bounded self-healing
- safety
- audit

---

# Deployment and operations

The release lifecycle is:

```text
PRECHECK
→ BACKUP
→ EXPAND
→ DEPLOY
→ MIGRATE
→ VERIFY
→ SWITCH
→ DRAIN
→ CONTRACT
→ AUDIT
```

Blue/green deployment:

```text
prepare green
    ↓
health checks
    ↓
smoke tests
    ↓
explicit traffic switch
    ↓
drain blue
    ↓
verify
    ↓
rollback remains available
```

Database changes prefer:

```text
EXPAND
→ MIGRATE
→ VERIFY
→ SWITCH
→ CONTRACT
```

Production deployment requires the relevant staging evidence, certification, operational preflight and explicit approval.

Coding agents do not SSH directly into production.

---

# Documentation and ReadMe

The project separates public and internal documentation.

```text
n8n-agent-ddd
│
├── docs/
│     └── internal engineering documentation
│
└── documentation/
      └── curated public documentation
              │
              ▼
      n8n-agent-ddd-docs
              ↕
      ReadMe bi-directional sync
```

The dedicated `n8n-agent-ddd-docs` repository is intended to be the public Git endpoint connected to ReadMe.

The main engine repository remains responsible for:

- code
- specifications
- workflows
- tests
- infrastructure
- internal documentation

The public documentation repository contains only documentation intended for external users and developers.

### ReadMe sync status

**0.20.3 prepares the repository architecture and migration path. It does not claim that a live GitHub ↔ ReadMe connection has already been executed.**

The initial ReadMe connection is a provider-side setup step. Once connected, ReadMe's Git Sync provides the bidirectional Git ↔ ReadMe relationship.

---

# Release line and roadmap

The project has evolved through the following major phases:

| Version | Focus |
|---|---|
| 0.1 | Foundation |
| 0.2 | AI-SDLC |
| 0.3 | Skills |
| 0.4 | DDD platform |
| 0.5 | n8n runtime |
| 0.6 | Tunisia DTC domain |
| 0.7 | Durable state |
| 0.8 | Supabase hardening |
| 0.9 | Staging integration |
| 0.10 | Multi-channel, data-plane and control-plane foundations |
| 0.11 | Production deployment foundation |
| 0.12 | Autonomous operations foundation |
| 0.13 | Provider-neutral runtime |
| 0.14 | Real-runtime integration foundation |
| 0.15 | Evidence and certification |
| 0.16 | Production operationalization |
| 0.17 | Harness Control Plane |
| 0.18 | Agent-Installable Platform |
| 0.19 | Autonomous AI-SDLC & Operations |
| 0.20 | Multi-Domain Platform / Ecosystem |
| 0.20.1 | Public/internal documentation split |
| 0.20.2 | Documentation audit and privacy boundary |
| 0.20.3 | ReadMe bi-directional documentation architecture |

### Current status

The 0.17–0.20 series establishes the architectural and operational foundation for the next maturity stage.

The project does **not** claim production certification solely because these repository phases exist.

The next maturity work is focused on:

- real runtime evidence
- staging execution
- operational validation
- certification
- deployment hardening
- ecosystem/domain-pack maturity
- eventual 1.0 stabilization

---


## Open-source project files

The repository maintains the standard public OSS governance and legal surface:

| File | Purpose |
|---|---|
| `LICENSE` | Apache License 2.0 terms |
| `NOTICE` | Project and third-party attribution notices |
| `CONTRIBUTING.md` | Contributor workflow and engineering expectations |
| `SECURITY.md` | Security policy and vulnerability handling |
| `GOVERNANCE.md` | Project governance and decision-making |
| `CODE_OF_CONDUCT.md` | Community participation standards |
| `SUPPORT.md` | Support and issue guidance |
| `CHANGELOG.md` | Release history and material changes |

These files are part of the public repository contract and should be kept synchronized with project behavior and release policy.

# Contributing

Contributions are welcome across:

- platform architecture
- domain packs
- n8n workflows
- adapters
- security
- testing
- infrastructure
- Harness
- AI-SDLC
- documentation

Before contributing:

1. Understand the relevant specification.
2. Identify affected domain/platform contracts.
3. Define acceptance criteria.
4. Implement the smallest coherent change.
5. Add or update tests.
6. Run security validation for security-sensitive changes.
7. Run architecture validation where boundaries are affected.
8. Update documentation when behavior changes.
9. Submit the change through normal Git review.

### Contribution principle

> **A feature is not complete when the code works locally. It is complete when its contracts, tests, security implications, documentation and operational behavior are understood.**

A dedicated `CONTRIBUTING.md` should be maintained as the canonical contributor guide before the project reaches stable 1.0.

---

# Security

Security issues should be handled through the project's dedicated security-disclosure process rather than public issue threads.

The security model is centered on:

- explicit authorization
- least privilege
- identity assurance
- secret isolation
- domain isolation
- input validation
- prompt-injection resistance
- idempotency
- reconciliation
- auditability
- bounded automation
- human escalation

Before 1.0, the repository should contain a complete public `SECURITY.md` with the supported disclosure channel, response expectations and security-policy scope.

---

# Governance

The project separates:

- platform architecture
- domain ownership
- security authority
- release authority
- contributor review
- operational approval

Architecture and high-impact changes should be reviewable and traceable.

A dedicated `GOVERNANCE.md` should document the maintainer model, decision process, release authority and architectural decision process before stable 1.0.

---

# Code of Conduct

Contributors are expected to participate respectfully and professionally.

A dedicated `CODE_OF_CONDUCT.md` should be included in the repository's public OSS surface before community launch.

---

# Support

Use the project's public documentation first for:

- installation
- configuration
- development
- deployment
- operations
- troubleshooting

For bugs, use the repository issue process.

For security issues, use the private security disclosure process rather than a public issue.

A dedicated `SUPPORT.md` should define the final support channels and expectations before stable 1.0.

---

# Changelog

Release history is maintained separately from this README.

The changelog should record:

- version
- release date
- new capabilities
- behavior changes
- breaking changes
- migrations
- security changes
- documentation changes
- operational implications

See `CHANGELOG.md` when available.

---

# License

The project is intended to be released under the **Apache License 2.0**.

The repository should include the complete `LICENSE` and, where required, `NOTICE` files at the repository root before a stable public release.

---

# Acknowledgements

n8n Agent DDD builds on and integrates with the broader open-source and developer-tool ecosystem.

The project intentionally keeps provider-specific capabilities behind adapters and contracts so the core domain architecture is not coupled to a single vendor.

Attribution and third-party license obligations should be maintained in the repository's `NOTICE` / third-party attribution process.

---

## Project philosophy

n8n Agent DDD is built around a simple idea:

> **Autonomous agents should be treated as software systems, not just prompts.**

A useful business agent needs:

```text
Reasoning
+
Domain logic
+
State
+
Authorization
+
Tools
+
Verification
+
Security
+
Observability
+
Deployment
+
Reconciliation
+
Human ownership
```

n8n provides the orchestration runtime.

The domain model provides business meaning.

PostgreSQL provides durable state.

Adapters connect the system to channels and external providers.

WF-10 protects consequential actions.

WF-20 protects commerce execution.

Harness provides the developer/AI control plane.

And the evidence framework determines what the system can legitimately claim about its runtime maturity.

---

**n8n Agent DDD — build autonomous business agents with explicit domain boundaries, deterministic orchestration, and controlled autonomy.**
