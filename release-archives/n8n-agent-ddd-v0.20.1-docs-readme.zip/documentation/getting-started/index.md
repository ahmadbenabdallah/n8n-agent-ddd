---
title: Getting Started
category: Getting Started
order: 1
---

# Getting Started

`n8n-agent-ddd` is an open-source domain-driven autonomous agent runtime built around n8n.

The fastest way to understand the project is to keep two layers separate:

1. **Customer runtime:** n8n + domain runtime + adapters + durable state.
2. **Developer control plane:** Harness + Skills + MCP + Git + CI.

## Who should use this project?

### Runtime operators

Use the installation, configuration, deployment, and operations guides to run a domain agent.

### Developers

Use the development guides to add workflows, domain logic, adapters, skills, tests, and releases.

### AI coding agents

Claude Code and Codex can use Harness commands and repository contracts to plan, implement, test, validate, and prepare deployment work.

## Important status note

The repository contains production-oriented contracts and evidence tooling, but a contract existing in Git is not proof that the corresponding live operation has been executed. Live evidence must be captured before claiming certification.
