---
title: Core Concepts
category: Getting Started
order: 2
---

# Core Concepts

## Domain-driven runtime

Business rules live in a domain pack rather than inside an LLM prompt or a provider-specific adapter.

## Workflows

The reference runtime contains 21 canonical workflows, WF-00 through WF-20.

The important execution boundary is:

`LLM proposal → validation → WF-10 authorization → WF-20 commerce execution → verification → response → audit`

## Ports and adapters

The platform separates business logic from external providers with ports such as:

- ChannelPort
- CommercePort
- IdentityPort
- PaymentPort
- KnowledgePort
- ObservabilityPort

## Durable state

PostgreSQL/Supabase is the durable application/domain state layer. n8n is orchestration, not the owner of critical business state.

## Domain isolation

Each domain has a stable `domain_id` and scoped workflow, data, knowledge, authorization, and audit boundaries. Cross-domain access is denied by default.

## Assisted Commerce

If no live commerce adapter is available, informational questions can still use the knowledge layer. Transactional requests collect the necessary information and escalate rather than pretending that a live commerce mutation occurred.
