---
title: Installation
category: Installation
order: 1
---

# Installation

## Supported deployment shapes

The platform is provider-neutral. Common profiles include:

- Local: PostgreSQL + n8n in Docker
- n8n remote: n8n on a provider/VPS with external PostgreSQL
- VPS all-in-one: n8n + PostgreSQL on a VPS
- Managed provider: n8n container with managed/external PostgreSQL

Docker is the packaging boundary; the provider is an adapter.

## Prerequisites

For local development, install:

- Git
- Bash
- Node.js
- pnpm
- Docker and Docker Compose

For production, also provide:

- persistent PostgreSQL
- persistent n8n data
- persistent `N8N_ENCRYPTION_KEY`
- HTTPS
- deployment-managed secrets
- backup storage
- a controlled operator access path

## Harness bootstrap

Run:

```bash
./scripts/harness/install.sh
./scripts/harness/init.sh
./scripts/harness/doctor.sh
./scripts/harness/configure.sh
```

The bootstrap is designed to be safe to rerun. Doctor checks prerequisites and contract files without printing secret values.

## Local runtime

The local runtime contract uses PostgreSQL and n8n in Docker. Follow the runtime scripts and environment examples under `infrastructure/` and `scripts/runtime/`.

Do not copy production secrets into the repository or into agent context.

## Production

Production deployment is gated. Do not treat local installation success as production readiness. Production requires the certification and operational evidence defined by the release contracts.
