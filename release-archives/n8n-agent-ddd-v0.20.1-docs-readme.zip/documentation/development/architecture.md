---
title: Architecture Guidelines
category: Development
order: 2
---

# Architecture Guidelines

## Layering

Prefer:

```text
Domain
  ↓
Platform contracts
  ↓
Ports
  ↓
Adapters
  ↓
Infrastructure
```

Domain logic must not depend on a specific vendor API.

## Business truth

Commerce providers remain authoritative for live product, price, inventory, promotion, and order state when an adapter exists.

Knowledge is secondary for live commerce facts.

## Authorization

`LLM proposal → n8n validation → WF-10 authorization → WF-20 execution`

Only the authorized branch can produce an execution-approved decision.

## Identity

Identity assurance progresses through:

`ANONYMOUS → CHANNEL-LINKED → COMMERCE-MATCHED → ORDER-VERIFIED → HIGH-ASSURANCE`

The LLM cannot promote identity.

## State

Critical state belongs in durable PostgreSQL/Supabase-backed storage. n8n coordinates execution but is replaceable.

## Idempotency

Every externally visible mutation needs an idempotency strategy. Unknown outcomes require reconciliation.

## Domain isolation

Cross-domain access is denied by default and requires an explicit contract, authorization, and audit coverage.
