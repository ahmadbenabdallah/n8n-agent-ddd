---
title: Developer Guide
category: Development
order: 1
---

# Developer Guide

## Source of truth

Git is the engineering source of truth.

Use pull requests for:

- code
- workflows
- domain changes
- policies
- skills
- documentation
- release definitions

Generated runtime state is not the canonical engineering source.

## Before changing anything

1. Read the relevant architecture contract.
2. Identify the domain and affected workflows.
3. Identify authorization/security impact.
4. Identify migration impact.
5. Define acceptance criteria.
6. Define tests and evidence required.
7. Work in an isolated branch/worktree.

## Definition of Ready

A task is ready when the affected domain/workflows are known, contracts are identified, acceptance criteria are explicit, security impact is understood, and rollback/migration requirements are known.

## Definition of Done

A change is done only when implementation, tests, security review, architecture review, documentation, and required evidence are complete.

## Never bypass the boundaries

Do not:

- let the LLM execute commerce mutations directly
- move authorization into prompts
- bypass WF-10
- put privileged commerce credentials in customer/LLM context
- store business truth only in n8n execution data
- SSH directly into production from a coding agent
- silently weaken a security policy to make a test pass
