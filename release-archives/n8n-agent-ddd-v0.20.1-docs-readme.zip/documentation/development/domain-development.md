---
title: Domain Development
category: Development
order: 3
---

# Domain Development

A domain pack contains:

```text
domain.yaml
domain-project.yaml
business/
entities/
aggregates/
value-objects/
commands/
events/
policies/
projections/
workflows/
knowledge/
adapters/
tests/
```

## Domain rules

Keep domain concepts provider-neutral.

For commerce domains, use canonical concepts such as:

- Product
- Variant
- Cart
- CartItem
- Order
- OrderItem
- Promotion

Provider IDs are references, not domain identity.

## Adding a new domain

1. Create a stable `domain_id`.
2. Define business language and invariants.
3. Define aggregates, commands, and events.
4. Define workflows and authorization requirements.
5. Select channel and provider adapters.
6. Define knowledge scope.
7. Define tests and security cases.
8. Define the n8n project and workflow namespace.
9. Validate isolation.
10. Add deployment profile configuration.

Do not copy the Tunisia DTC business rules into a new domain. Reuse platform contracts and write domain-specific rules.
