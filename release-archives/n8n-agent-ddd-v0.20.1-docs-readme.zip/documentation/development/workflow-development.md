---
title: n8n Workflow Development
category: Development
order: 4
---

# n8n Workflow Development

The platform uses n8n for orchestration.

## Canonical workflows

The reference runtime has exactly 21 canonical workflows:

WF-00 through WF-20.

Protected workflows include:

- WF-01 Security Gate
- WF-10 Action Authorization
- WF-15 Transaction/Payment
- WF-20 WooCommerce Gateway

Protected workflows require release-controlled changes.

## Workflow rules

- Keep workflow responsibility narrow.
- Validate input at boundaries.
- Do not embed hidden authorization logic in prompts.
- Keep provider-specific behavior in adapters.
- Emit auditable state transitions for mutations.
- Use idempotency for mutations.
- Verify external state after mutations.
- Keep secrets in n8n credentials/deployment secret mechanisms, not plain nodes or prompts.

## Operator UI

Do not build a competing workflow editor. n8n already provides the operator-facing dashboard for workflow editing, credentials, projects, and executions.
