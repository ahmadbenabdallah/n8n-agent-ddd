---
title: AI Coding Agents
category: Development
order: 7
---

# AI Coding Agents

Claude Code and Codex are first-class development clients for the Harness control plane.

## Expected flow

```text
Task
 ↓
Chief / planner
 ↓
PM + Architect + Security
 ↓
task graph
 ↓
isolated worktree
 ↓
Developer agent
 ↓
QA
 ↓
Security review
 ↓
Architecture review
 ↓
human/release approval
 ↓
Git/CI
```

## Agent rules

Agents should:

- inspect contracts before editing
- keep work scoped to a task
- use isolated worktrees
- run relevant tests
- preserve evidence
- request review for high-impact actions
- use Git/CI for remote deployment

Agents should not:

- SSH directly into production
- bypass CI
- bypass WF-10
- access production secrets by default
- silently alter authorization policy
- claim live execution without evidence

## Session state

Durable state may contain task metadata, decisions, artifacts, blockers, and evidence references. Secret values and credential material are excluded.
