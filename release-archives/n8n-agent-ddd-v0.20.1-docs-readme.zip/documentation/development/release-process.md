---
title: Release Process
category: Development
order: 8
---

# Release Process

## Release flow

```text
PLAN
→ IMPLEMENT
→ TEST
→ SECURITY REVIEW
→ ARCHITECTURE REVIEW
→ CI
→ MERGE
→ STAGING
→ EVIDENCE
→ CERTIFICATION
→ APPROVAL
→ PRODUCTION
→ VERIFY
```

## Versioning

Runtime, business policy, security policy, LLM prompt/model, knowledge base, and database schema are independently versioned in the release manifest.

## Database changes

Use:

`EXPAND → MIGRATE → VERIFY → SWITCH → CONTRACT`

Destructive changes require explicit review and a rollback strategy.

## Production

A production deployment is not implied by a merged pull request. The operational and certification gates must be satisfied and explicit approval must be present.
