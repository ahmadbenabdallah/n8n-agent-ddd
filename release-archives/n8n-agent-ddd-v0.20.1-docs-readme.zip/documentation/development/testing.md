---
title: Testing and Evidence
category: Development
order: 5
---

# Testing and Evidence

Use the smallest test that proves the invariant, then run broader gates when the change requires them.

## Test layers

- unit
- integration
- architecture
- security
- red-team
- end-to-end
- disaster recovery

## Security cases

High-impact changes should consider:

- prompt injection
- retrieved-content injection
- forged authorization
- scope escalation
- cross-customer access
- cross-domain access
- protected workflow mutation
- secret exfiltration
- sensitive log injection
- arbitrary endpoint execution
- price/stock/payment manipulation
- replay
- human-ownership conflicts

## Evidence rule

Never mark a live operational gate successful without captured runtime evidence.

A contract test proves the repository contract. It does not prove a real provider, channel, database, n8n instance, backup, rollback, or production deployment worked.
