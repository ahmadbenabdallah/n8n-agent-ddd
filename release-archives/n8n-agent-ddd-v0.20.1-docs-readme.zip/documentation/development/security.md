---
title: Security Guidelines
category: Development
order: 6
---

# Security Guidelines

## Never expose

Do not put these in LLM or customer-visible context:

- PAN
- CVV
- OTP
- PIN
- passwords
- API keys
- provider secrets
- WooCommerce secrets
- cart tokens/nonces

## Authorization

MCP capability discovery, workflow visibility, or tool availability never grants business authorization.

Commerce authorization is enforced by WF-10.

## Secrets

Secrets must:

- be injected at runtime
- remain outside Git
- remain outside durable agent session state
- never be printed by doctor/status commands
- never be placed in evidence artifacts

## Security changes

Security-sensitive changes require:

1. threat-model review
2. targeted tests
3. red-team coverage where applicable
4. architecture review
5. release evidence
