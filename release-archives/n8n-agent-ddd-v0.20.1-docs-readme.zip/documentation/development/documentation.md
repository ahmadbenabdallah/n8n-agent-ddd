---
title: Documentation Guidelines
category: Development
order: 9
---

# Documentation Guidelines

## Source of truth

User-facing and developer-facing documentation lives in Git under `documentation/`.

ReadMe is the publishing layer.

## Writing rules

Every feature that changes user behavior should update:

- relevant getting-started/setup page
- configuration/deployment page when applicable
- developer guide when implementation contracts change
- changelog/release notes

Document operational claims carefully. Distinguish:

- repository contract
- tested local behavior
- staging evidence
- production evidence

Never turn a planned capability into a claim that it has been executed.

## ReadMe publishing

GitHub Actions publishes `documentation/` to ReadMe using ReadMe's official `rdme` action.

Required repository configuration:

- secret: `README_API_KEY`
- variable: `README_VERSION`

The workflow runs on changes to documentation and release metadata on `main`.

ReadMe documents both one-way `rdme` publishing and bi-directional Git sync. This repository uses the explicit CI publishing model so Git remains the source of truth for the project.
