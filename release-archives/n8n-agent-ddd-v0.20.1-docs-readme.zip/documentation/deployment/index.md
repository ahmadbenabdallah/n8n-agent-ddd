---
title: Deployment
category: Deployment
order: 1
---

# Deployment

The deployment model is:

`Git → CI gates → deployment contract → runtime → verification`

Coding agents must not SSH directly into production.

## Release lifecycle

```text
PRECHECK
→ BACKUP
→ EXPAND
→ DEPLOY
→ MIGRATE
→ VERIFY
→ SWITCH
→ DRAIN
→ CONTRACT
→ AUDIT
```

## Blue/green

The intended sequence is:

1. Build green.
2. Verify green health.
3. Run smoke tests.
4. Switch traffic explicitly.
5. Drain blue.
6. Keep rollback available.
7. Terminate old capacity only after verification.

## Rollback

Rollback is a controlled release operation. Do not blindly reverse database migrations. Expand/migrate/contract compatibility must be considered before switching.

## Production gate

Production requires:

- required staging evidence
- certification evidence
- operational preflight
- explicit approval
- deployment verification

A script or YAML contract stating that a gate exists is not evidence that the gate has passed in a real environment.
