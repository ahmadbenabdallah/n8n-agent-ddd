---
title: Documentation
category: Getting Started
order: 0
---

# Documentation

This directory is the source of truth for user-facing and developer-facing documentation.

## User

- Getting Started
- Installation
- Configuration
- Deployment
- Operations

## Developer

- Architecture
- Domain Development
- n8n Workflow Development
- Testing and Evidence
- Security
- AI Coding Agents
- Release Process
- Documentation

The repository publishes this directory to ReadMe through GitHub Actions.
