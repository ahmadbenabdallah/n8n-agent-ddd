---
title: Configuration
category: Configuration
order: 1
---

# Configuration

Configuration is divided into infrastructure, application/domain configuration, provider configuration, and secrets.

## Secrets

Secrets are injected by the deployment environment.

Examples include:

- n8n encryption key
- database credentials
- provider credentials
- channel credentials
- commerce credentials

Secret values must not be committed, logged, placed in LLM/customer-visible context, or stored in durable agent session state.

## Persistent n8n encryption key

`N8N_ENCRYPTION_KEY` must remain stable across restart, upgrade, blue/green deployment, and restore. Key rotation is a controlled operation.

## Application configuration

Business/application configuration should live in the durable configuration layer rather than in hard-coded workflow nodes.

## Environment separation

Keep separate configuration for:

- development
- staging
- production

Never use production credentials for development or staging.

## Domain configuration

A domain profile identifies:

- `domain_id`
- n8n project
- workflow namespace
- database scope
- knowledge namespace
- enabled channels
- enabled adapters
- policy bundle

Cross-domain access is denied by default.
