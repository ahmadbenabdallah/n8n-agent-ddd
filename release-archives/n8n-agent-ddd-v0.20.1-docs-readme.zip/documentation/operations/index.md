---
title: Operations
category: Operations
order: 1
---

# Operations

The runtime control loop is:

`OBSERVE → CLASSIFY → DECIDE → ACT → VERIFY → AUDIT → LEARN`

## Health

Runtime health can be:

- HEALTHY
- DEGRADED
- UNHEALTHY
- UNKNOWN
- MAINTENANCE

## Reconciliation

Reconciliation covers durable mutation state such as:

- orders
- transactions
- carts
- authorizations
- idempotency records

Unknown external outcomes must be reconciled before deciding whether another mutation is safe.

## Bounded self-healing

Allowed examples include:

- restarting a disposable worker
- bounded transient retry
- clearing a stale lock
- rescheduling reconciliation

Forbidden examples include:

- authorizing commerce
- changing price/stock/payment state
- bypassing WF-10
- blindly retrying an unknown mutation
- exporting or rotating secrets without the required process

Human ownership blocks conflicting automation.
