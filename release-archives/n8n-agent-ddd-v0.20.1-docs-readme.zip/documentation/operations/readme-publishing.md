---
title: ReadMe Publishing
category: Operations
order: 3
---

# ReadMe Publishing

Documentation is maintained in Git and published automatically to ReadMe by GitHub Actions.

## Required GitHub configuration

Create:

- `README_API_KEY` as a repository or environment secret
- `README_VERSION` as a repository variable matching the ReadMe project version/branch

Do not put the API key in YAML, Markdown, shell scripts, or commit history.

## Workflow

The workflow:

1. checks out the repository
2. publishes the `documentation/` directory with `readmeio/rdme@v10`
3. uses the configured ReadMe API key
4. targets the configured ReadMe version

## Trigger

The workflow runs on pushes to `main` when documentation or release metadata changes. It can also be started manually.

## Local validation

Install `rdme` in development if you want to validate or preview publishing behavior locally. Keep CI pinned to a known major version.

## Ownership

Git is the source of truth. ReadMe is the public publishing/hosting layer for this project.
