---
title: Troubleshooting
category: Operations
order: 2
---

# Troubleshooting

## n8n is unavailable

Check runtime health and the n8n container/service first. Do not recreate durable application state simply because orchestration is unavailable.

## PostgreSQL is unavailable

Treat PostgreSQL as durable state. Restore connectivity before attempting state-changing operations.

## A commerce mutation timed out

Do not blindly retry. The provider may have committed the mutation. Reconcile the external state first.

## A workflow is missing

Compare the live workflow inventory against the canonical 21-workflow set. Do not manually patch protected workflows outside the release process.

## A secret is missing

Check secret injection at the deployment layer. Do not paste the secret into logs, Git, tickets, LLM context, or customer messages.

## Domain access is leaking

Check every domain scope dimension: `domain_id`, n8n project, workflow namespace, database scope, knowledge namespace, authorization scope, and audit scope.

## Certification says NOT_READY

That is a safety state, not a runtime failure. Inspect the missing evidence gates and execute them in the appropriate staging environment before attempting production.
