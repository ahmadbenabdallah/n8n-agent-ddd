#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
required=(
  README.md
  CHANGELOG.md
  documentation/README.md
  documentation/getting-started/index.md
  documentation/installation/index.md
  documentation/configuration/index.md
  documentation/deployment/index.md
  documentation/operations/index.md
  documentation/development/index.md
  documentation/development/architecture.md
  documentation/development/domain-development.md
  documentation/development/workflow-development.md
  documentation/development/testing.md
  documentation/development/security.md
  documentation/development/ai-agents.md
  documentation/development/release-process.md
  documentation/development/documentation.md
  documentation/operations/readme-publishing.md
  .github/workflows/readme-docs.yml
)
for f in "${required[@]}"; do
  test -f "$ROOT/$f" || { echo "MISSING: $f"; exit 1; }
done
grep -q 'readmeio/rdme@v10' "$ROOT/.github/workflows/readme-docs.yml"
grep -q 'README_API_KEY' "$ROOT/.github/workflows/readme-docs.yml"
grep -q 'README_VERSION' "$ROOT/.github/workflows/readme-docs.yml"
grep -q 'documentation lives in Git' "$ROOT/documentation/development/documentation.md"
grep -Fq 'Harness is **not** the customer runtime' "$ROOT/README.md"
echo "Documentation contract successful."
