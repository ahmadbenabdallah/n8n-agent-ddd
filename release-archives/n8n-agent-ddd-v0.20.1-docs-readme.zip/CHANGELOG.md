# Changelog

## Unreleased

### Documentation

- Added a public user documentation tree under `documentation/`.
- Added developer guidelines for architecture, domains, n8n workflows, testing, security, AI agents, releases, and documentation.
- Added ReadMe publishing guidance.
- Added GitHub Actions automation to publish documentation to ReadMe from `main`.
- Clarified the separation between customer runtime, Harness control plane, n8n operator UI, and Git/CI source of truth.
